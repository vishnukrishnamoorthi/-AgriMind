from pathlib import Path
from pydantic_settings import BaseSettings, SettingsConfigDict

ROOT = Path(__file__).resolve().parents[2]

class Settings(BaseSettings):
    app_name: str = "AgriMind AI"
    secret_key: str = "development-only-secret-change-me"
    database_url: str = "sqlite:///./agrimind.db"
    access_token_expire_minutes: int = 480
    cors_origins: str = "*"
    open_meteo_enabled: bool = True
    bedrock_enabled: bool = False
    aws_region: str = "ap-south-1"
    bedrock_model_id: str = "amazon.nova-lite-v1:0"
    ai_max_tokens: int = 700
    ai_temperature: float = 0.2
    openai_api_key: str = ""
    openai_model: str = "gpt-4.1-mini"
    openai_timeout_seconds: float = 30.0
    openai_max_output_tokens: int = 700
    openai_rate_limit_per_minute: int = 20
    s3_bucket: str = ""
    mqtt_broker_url: str = ""
    model_dir: str = "ml/artifacts"
    model_config = SettingsConfigDict(env_file=ROOT / ".env", extra="ignore")

settings = Settings()
