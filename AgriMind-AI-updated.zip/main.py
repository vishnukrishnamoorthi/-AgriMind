import json, random
from datetime import datetime, timedelta
from pathlib import Path
from fastapi import Depends, FastAPI, File, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from sqlalchemy import func, select
from sqlalchemy.orm import Session
from .auth import current_user, hash_password, token_for, verify_password, require_roles
from .config import ROOT, settings
from .database import Base, engine, get_db, SessionLocal
from .models import Alert, Farm, PredictionLog, SensorReading, User
from .schemas import ChatIn, CropInput, FarmIn, IrrigationInput, LoginIn, RegisterIn, SensorIn, YieldInput
from . import services

app = FastAPI(title=settings.app_name, version="1.0.0", description="Local-first smart agriculture decision-support API")
app.add_middleware(CORSMiddleware, allow_origins=settings.cors_origins.split(","), allow_credentials=False, allow_methods=["*"], allow_headers=["*"])

def own_farm(db: Session, farm_id: int, user: User) -> Farm:
    farm=db.get(Farm,farm_id)
    if not farm: raise HTTPException(404,"Farm not found")
    if farm.owner_id != user.id and user.role not in {"admin","agronomist"}: raise HTTPException(403,"You do not have access to this farm")
    return farm
def log(db:Session,user:User,kind:str,data:dict): db.add(PredictionLog(user_id=user.id,kind=kind,payload=json.dumps(data)))

@app.on_event("startup")
def startup():
    Base.metadata.create_all(engine)
    db=SessionLocal()
    try:
        if not db.scalar(select(User.id).limit(1)):
            admin=User(name="Platform Admin",email="admin@agrimind.local",password_hash=hash_password("Admin@123"),role="admin")
            farmer=User(name="Demo Farmer",email="farmer@agrimind.local",password_hash=hash_password("Farmer@123"),role="farmer")
            agro=User(name="Demo Agronomist",email="agronomist@agrimind.local",password_hash=hash_password("Agronomist@123"),role="agronomist")
            db.add_all([admin,farmer,agro]); db.flush()
            farm=Farm(name="Green Valley Demo Farm",location="Coimbatore, Tamil Nadu",area_acres=4.5,crop="Rice",owner_id=farmer.id); db.add(farm); db.flush()
            for day in range(7):
                db.add(SensorReading(farm_id=farm.id,soil_moisture=42+day%3*3,temperature=29+day%2,humidity=64-day%4,rainfall=2 if day==3 else 0,nitrogen=76,phosphorus=38,potassium=41,captured_at=datetime.utcnow()-timedelta(days=6-day)))
            db.add(Alert(farm_id=farm.id,severity="medium",title="Demo moisture watch",message="This seeded alert demonstrates the notification workflow."))
            db.commit()
    finally: db.close()

@app.get("/api/health")
def health(): return {"status":"ok","app":settings.app_name,"time":datetime.utcnow()}
@app.post("/api/auth/register")
def register(data:RegisterIn,db:Session=Depends(get_db)):
    if data.role not in {"farmer","agronomist"}: raise HTTPException(400,"Role must be farmer or agronomist")
    if db.scalar(select(User).where(User.email==data.email.lower())): raise HTTPException(409,"Email is already registered")
    user=User(name=data.name,email=data.email.lower(),password_hash=hash_password(data.password),role=data.role);db.add(user);db.commit();db.refresh(user)
    return {"token":token_for(user),"user":{"id":user.id,"name":user.name,"email":user.email,"role":user.role}}
@app.post("/api/auth/login")
def login(data:LoginIn,db:Session=Depends(get_db)):
    user=db.scalar(select(User).where(User.email==data.email.lower()))
    if not user or not verify_password(data.password,user.password_hash): raise HTTPException(401,"Invalid email or password")
    return {"token":token_for(user),"user":{"id":user.id,"name":user.name,"email":user.email,"role":user.role}}
@app.get("/api/auth/me")
def me(user:User=Depends(current_user)): return {"id":user.id,"name":user.name,"email":user.email,"role":user.role}

@app.get("/api/farms")
def farms(user:User=Depends(current_user),db:Session=Depends(get_db)):
    stmt=select(Farm) if user.role in {"admin","agronomist"} else select(Farm).where(Farm.owner_id==user.id)
    return [{"id":f.id,"name":f.name,"location":f.location,"area_acres":f.area_acres,"crop":f.crop,"owner_id":f.owner_id} for f in db.scalars(stmt).all()]
@app.post("/api/farms")
def add_farm(data:FarmIn,user:User=Depends(current_user),db:Session=Depends(get_db)):
    f=Farm(**data.model_dump(),owner_id=user.id);db.add(f);db.commit();db.refresh(f);return {"id":f.id,"name":f.name}
@app.get("/api/farms/{farm_id}/sensors")
def sensor_history(farm_id:int,limit:int=30,user:User=Depends(current_user),db:Session=Depends(get_db)):
    own_farm(db,farm_id,user); rows=db.scalars(select(SensorReading).where(SensorReading.farm_id==farm_id).order_by(SensorReading.captured_at.desc()).limit(min(limit,200))).all()
    return [{"id":r.id,"soil_moisture":r.soil_moisture,"temperature":r.temperature,"humidity":r.humidity,"rainfall":r.rainfall,"nitrogen":r.nitrogen,"phosphorus":r.phosphorus,"potassium":r.potassium,"captured_at":r.captured_at} for r in rows]
@app.post("/api/farms/{farm_id}/sensors")
def ingest_sensor(farm_id:int,data:SensorIn,user:User=Depends(current_user),db:Session=Depends(get_db)):
    own_farm(db,farm_id,user); r=SensorReading(farm_id=farm_id,**data.model_dump());db.add(r);db.flush();services.create_sensor_alerts(db,r);db.commit();db.refresh(r);return {"id":r.id,"captured_at":r.captured_at,"message":"Sensor reading stored and alert rules checked"}
@app.post("/api/farms/{farm_id}/simulate-sensor")
def simulate_sensor(farm_id:int,user:User=Depends(current_user),db:Session=Depends(get_db)):
    f=own_farm(db,farm_id,user);data=SensorIn(soil_moisture=round(random.uniform(22,70),1),temperature=round(random.uniform(25,40),1),humidity=round(random.uniform(38,85),1),rainfall=round(random.uniform(0,8),1),nitrogen=round(random.uniform(50,110),1),phosphorus=round(random.uniform(25,60),1),potassium=round(random.uniform(25,65),1)); return ingest_sensor(farm_id,data,user,db)

@app.post("/api/predictions/crop")
def predict_crop(data:CropInput,user:User=Depends(current_user),db:Session=Depends(get_db)):
    out=services.crop_recommendation(data.model_dump());log(db,user,"crop",out);db.commit();return out
@app.post("/api/predictions/yield")
def predict_yield(data:YieldInput,user:User=Depends(current_user),db:Session=Depends(get_db)):
    out=services.yield_prediction(data.model_dump());log(db,user,"yield",out);db.commit();return out
@app.post("/api/predictions/irrigation")
def predict_irrigation(data:IrrigationInput,user:User=Depends(current_user),db:Session=Depends(get_db)):
    out=services.irrigation_plan(data.model_dump());log(db,user,"irrigation",out);db.commit();return out
@app.post("/api/predictions/fertilizer")
def fertilizer(data:CropInput,user:User=Depends(current_user),db:Session=Depends(get_db)):
    out=services.fertilizer_review(data.model_dump());log(db,user,"fertilizer",out);db.commit();return out
@app.post("/api/predictions/disease")
async def disease(image:UploadFile=File(...),user:User=Depends(current_user),db:Session=Depends(get_db)):
    if not image.content_type or not image.content_type.startswith("image/"): raise HTTPException(400,"Upload an image file")
    try:
        out=services.disease_screen(await image.read())
    except ValueError as exc:
        raise HTTPException(400,str(exc)) from exc
    except RuntimeError as exc:
        raise HTTPException(503,str(exc)) from exc
    log(db,user,"disease",out);db.commit();return out

@app.get("/api/weather")
async def get_weather(
    location: str = "Coimbatore, India",
    latitude: float | None = None,
    longitude: float | None = None,
    user: User = Depends(current_user),
):
    if (latitude is None) != (longitude is None):
        raise HTTPException(400, "latitude and longitude must be provided together")
    if latitude is not None and not -90 <= latitude <= 90:
        raise HTTPException(400, "latitude must be between -90 and 90")
    if longitude is not None and not -180 <= longitude <= 180:
        raise HTTPException(400, "longitude must be between -180 and 180")
    return await services.weather(location, latitude=latitude, longitude=longitude)
@app.get("/api/alerts")
def alerts(status:str="open",user:User=Depends(current_user),db:Session=Depends(get_db)):
    permitted={f.id for f in db.scalars(select(Farm) if user.role in {"admin","agronomist"} else select(Farm).where(Farm.owner_id==user.id)).all()}
    rows=db.scalars(select(Alert).where(Alert.status==status).order_by(Alert.created_at.desc())).all()
    return [{"id":a.id,"farm_id":a.farm_id,"severity":a.severity,"title":a.title,"message":a.message,"status":a.status,"created_at":a.created_at} for a in rows if a.farm_id in permitted]

@app.get("/api/market/vegetables")
async def vegetable_market_terms(_:User=Depends(current_user)):
    prices = await services.tamilnadu_vegetable_prices()
    return {
        "prices": prices,
        "disclaimer": "Indicative planning guidance only. Confirm price, grade, quantity, transport, and payment terms with the buyer before dispatch.",
        "vegetables": [
            {"name": "Tomato", "unit": "kg", "quality": "Firm, clean, sorted by maturity"},
            {"name": "Onion", "unit": "kg", "quality": "Cured, dry outer skin, no sprouting"},
            {"name": "Okra", "unit": "kg", "quality": "Tender pods, uniform size, no bruising"},
            {"name": "Brinjal", "unit": "kg", "quality": "Glossy skin, firm fruit, no cuts"},
            {"name": "Leafy greens", "unit": "bundle", "quality": "Fresh, hydrated, yellow-free leaves"},
        ],
        "terms": [
            ("Price basis", "Record whether the price is per kg, crate, bundle, or lot, and whether it is fixed or linked to the market rate."),
            ("Quality and grading", "Agree on size, maturity, cleanliness, acceptable damage, and rejection rules before harvest."),
            ("Quantity and weighing", "Confirm estimated quantity, weighing location, scale responsibility, and the final accepted weight."),
            ("Pickup and delivery", "Write down pickup date, delivery window, transport responsibility, and who pays loading or freight."),
            ("Payment", "Confirm total amount, deductions, payment method, and due date. Keep the receipt or digital transaction record."),
            ("Cancellation", "Agree what happens if the buyer cancels, the crop is delayed, or quality changes after harvest."),
        ],
    }
@app.post("/api/alerts/{alert_id}/resolve")
def resolve_alert(alert_id:int,user:User=Depends(current_user),db:Session=Depends(get_db)):
    a=db.get(Alert,alert_id)
    if not a: raise HTTPException(404,"Alert not found")
    own_farm(db,a.farm_id,user);a.status="resolved";db.commit();return {"message":"Alert resolved"}
@app.get("/api/analytics/overview")
def overview(user:User=Depends(current_user),db:Session=Depends(get_db)):
    farms_list=db.scalars(select(Farm) if user.role in {"admin","agronomist"} else select(Farm).where(Farm.owner_id==user.id)).all();ids=[f.id for f in farms_list]
    readings=db.scalars(select(SensorReading).where(SensorReading.farm_id.in_(ids)).order_by(SensorReading.captured_at.desc()).limit(30)).all() if ids else []
    open_alerts=db.scalar(select(func.count(Alert.id)).where(Alert.farm_id.in_(ids),Alert.status=="open")) if ids else 0
    return {"farm_count":len(farms_list),"total_acres":round(sum(f.area_acres for f in farms_list),2),"open_alerts":open_alerts or 0,"latest_reading":({"soil_moisture":readings[0].soil_moisture,"temperature":readings[0].temperature,"humidity":readings[0].humidity,"captured_at":readings[0].captured_at} if readings else None),"moisture_trend":[{"at":r.captured_at,"value":r.soil_moisture} for r in reversed(readings)]}

@app.get("/api/analytics/live-crop")
def live_crop(user:User=Depends(current_user),db:Session=Depends(get_db)):
    farms_list = db.scalars(
        select(Farm) if user.role in {"admin", "agronomist"}
        else select(Farm).where(Farm.owner_id == user.id)
    ).all()
    latest = None
    latest_farm = None
    for farm in farms_list:
        reading = db.scalar(
            select(SensorReading)
            .where(SensorReading.farm_id == farm.id)
            .order_by(SensorReading.captured_at.desc())
            .limit(1)
        )
        if reading and (latest is None or reading.captured_at > latest.captured_at):
            latest, latest_farm = reading, farm
    if not latest or not latest_farm:
        return {"available": False, "message": "Waiting for the first sensor reading."}
    reading_data = {
        "soil_moisture": latest.soil_moisture,
        "temperature": latest.temperature,
        "humidity": latest.humidity,
        "rainfall": latest.rainfall,
        "captured_at": latest.captured_at,
    }
    return {
        "available": True,
        "farm_id": latest_farm.id,
        "farm_name": latest_farm.name,
        **services.live_crop_analysis(reading_data, latest_farm.crop),
    }
@app.post("/api/assistant/chat")
async def assistant_chat(data:ChatIn,user:User=Depends(current_user),db:Session=Depends(get_db)):
    if (data.latitude is None) != (data.longitude is None):
        raise HTTPException(400, "latitude and longitude must be provided together")
    out = await services.ai_assistant(
        data.question,
        response_language=data.response_language,
        voice_language=data.voice_language,
        location=data.location,
        latitude=data.latitude,
        longitude=data.longitude,
    )
    log(db,user,"assistant",out);db.commit();return out
@app.get("/api/admin/users")
def list_users(_:User=Depends(require_roles("admin")),db:Session=Depends(get_db)):
    return [{"id":u.id,"name":u.name,"email":u.email,"role":u.role,"created_at":u.created_at} for u in db.scalars(select(User).order_by(User.created_at.desc())).all()]

FRONTEND=ROOT/"frontend"
app.mount("/assets",StaticFiles(directory=FRONTEND),name="assets")
@app.get("/",include_in_schema=False)
def root(): return FileResponse(FRONTEND/"index.html")
