"""Prediction, weather, alert, and local RAG services. All fall back safely for demos."""
import asyncio, io, json, math, random, re
from datetime import datetime
from functools import lru_cache
from pathlib import Path
import httpx
from sqlalchemy.orm import Session
from .config import ROOT, settings
from .models import Alert, SensorReading

CROP_PROFILES = {
    "Rice": {"n": 90, "p": 42, "k": 43, "temp": 27, "rain": 190},
    "Maize": {"n": 110, "p": 50, "k": 45, "temp": 24, "rain": 95},
    "Cotton": {"n": 85, "p": 35, "k": 40, "temp": 29, "rain": 75},
    "Chickpea": {"n": 25, "p": 55, "k": 45, "temp": 22, "rain": 55},
    "Banana": {"n": 120, "p": 45, "k": 70, "temp": 28, "rain": 140},
}
def crop_recommendation(x: dict) -> dict:
    scores = []
    for crop, p in CROP_PROFILES.items():
        d = abs(x["nitrogen"]-p["n"])/p["n"] + abs(x["phosphorus"]-p["p"])/p["p"] + abs(x["potassium"]-p["k"])/p["k"] + abs(x["temperature"]-p["temp"])/15 + abs(x["rainfall"]-p["rain"])/200 + abs(x["ph"]-6.5)/7
        scores.append((crop, max(0.05, 1/(1+d))))
    scores.sort(key=lambda v: v[1], reverse=True); total = sum(s for _, s in scores)
    ranked = [{"crop": c, "confidence": round(s/total*100, 1)} for c,s in scores]
    return {"recommended_crop": ranked[0]["crop"], "confidence": ranked[0]["confidence"], "alternatives": ranked[1:3], "mode": "local rule model", "disclaimer": "Validate with local crop calendars, soil tests, water availability, and an agronomist."}
def yield_prediction(x: dict) -> dict:
    base = {"rice": 2.7, "maize": 2.3, "cotton": 0.8, "banana": 12.0}.get(x["crop"].lower(), 1.8)
    nutrition = min(1.15, 0.75 + x["nitrogen"]/300); water = min(1.1, 0.65+x["rainfall"]/500+x["soil_moisture"]/250)
    heat = max(.6, 1-abs(x["temperature"]-27)/40); per_acre = round(base*nutrition*water*heat, 2)
    return {"yield_tonnes_per_acre": per_acre, "total_tonnes": round(per_acre*x["area_acres"],2), "confidence_band": "±25%", "drivers": ["synthetic baseline", "nutrient estimate", "water and temperature proxy"], "mode":"local estimator"}
def irrigation_plan(x: dict) -> dict:
    target = {"rice": 65, "banana": 60, "cotton": 48, "maize": 50}.get(x["crop"].lower(), 50)
    deficit = max(0, target - x["soil_moisture"])
    heat_factor = max(0.7, min(1.4, 1+(x["temperature"]-25)/50-(x["humidity"]-55)/200))
    rain_credit = min(deficit, x["rainfall_forecast"]*0.6)
    litres = round(max(0, (deficit-rain_credit)*45*x["area_acres"]*heat_factor))
    urgency = "high" if deficit > 20 and x["rainfall_forecast"] < 4 else "medium" if deficit > 8 else "low"
    return {"irrigation_litres": litres, "urgency": urgency, "target_moisture": target, "suggested_window": "early morning", "note": "Check root-zone moisture and irrigation-system flow before applying water."}
def fertilizer_review(x: dict) -> dict:
    gaps = {"nitrogen": max(0,90-x["nitrogen"]), "phosphorus": max(0,42-x["phosphorus"]), "potassium": max(0,43-x["potassium"])}
    needs = [k for k,v in gaps.items() if v>10]
    return {"nutrient_gaps": gaps, "priority": needs or ["No major gap in demo thresholds"], "guidance": "Use a certified soil test and local extension recommendation to determine product, dose, timing, and legal restrictions. Do not treat this screen as a fertilizer prescription."}

def live_crop_analysis(reading: dict, crop: str) -> dict:
    """Turn the newest sensor reading into a transparent, non-diagnostic field signal."""
    signals = []
    score = 100
    moisture = reading["soil_moisture"]
    temperature = reading["temperature"]
    humidity = reading["humidity"]
    if moisture < 28:
        score -= 35
        signals.append({"level": "high", "label": "Moisture is low", "detail": "Inspect root-zone moisture and irrigation lines."})
    elif moisture < 40:
        score -= 15
        signals.append({"level": "medium", "label": "Moisture is trending low", "detail": "Recheck the field before the next irrigation window."})
    if temperature > 38:
        score -= 25
        signals.append({"level": "medium", "label": "Heat stress risk", "detail": "Schedule a field check during the cooler part of the day."})
    if humidity > 85:
        score -= 10
        signals.append({"level": "low", "label": "Humidity is high", "detail": "Increase scouting for fungal symptoms."})
    status = "Healthy" if score >= 80 else "Watch" if score >= 55 else "Action needed"
    recommendation = (
        "Conditions look stable. Continue routine monitoring."
        if status == "Healthy"
        else "Prioritise a field inspection and confirm the next irrigation decision."
        if status == "Watch"
        else "Inspect the field now and verify irrigation before making crop-management changes."
    )
    return {
        "crop": crop,
        "status": status,
        "health_score": score,
        "recommendation": recommendation,
        "signals": signals,
        "reading": reading,
    }
@lru_cache(maxsize=1)
def _load_disease_model():
    try:
        import tensorflow as tf
    except ImportError as exc:
        raise RuntimeError("TensorFlow is not installed. Install computer_vision/requirements.txt and train the disease model.") from exc

    model_path = Path(settings.model_dir)
    if not model_path.is_absolute():
        model_path = ROOT / model_path
    if model_path.is_dir():
        model_path /= "disease_model.keras"
    if not model_path.exists():
        raise RuntimeError(f"Disease model not found at {model_path}. Train computer_vision/train.py first.")

    labels_path = Path(f"{model_path}.labels.txt")
    if not labels_path.exists():
        raise RuntimeError(f"Disease model labels not found at {labels_path}.")
    labels = [label.strip() for label in labels_path.read_text(encoding="utf-8").splitlines() if label.strip()]
    if not labels:
        raise RuntimeError(f"Disease model labels file is empty: {labels_path}.")
    return tf.keras.models.load_model(model_path), labels


DISEASE_REFERENCE_URL = "https://earthsally.com/disease-control/common-plant-diseases.html"


def disease_screen(image) -> dict:
    try:
        import numpy as np
        from PIL import Image, UnidentifiedImageError
    except ImportError as exc:
        raise RuntimeError("NumPy and Pillow are required for image screening.") from exc

    if isinstance(image, Image.Image):
        pil_image = image
    else:
        try:
            pil_image = Image.open(io.BytesIO(image))
        except (TypeError, UnidentifiedImageError, OSError) as exc:
            raise ValueError("The uploaded file is not a valid image.") from exc

    try:
        import tensorflow as tf
        model, labels = _load_disease_model()
    except (ImportError, RuntimeError):
        return {
            "label": "Model unavailable: image received",
            "confidence": None,
            "mode": "demo upload validation",
            "next_steps": "Train the EfficientNet model and repeat the screening before making crop-management decisions.",
            "safety": "This upload was validated, but no disease classification was made and no pesticide recommendation is generated.",
            "reference_url": DISEASE_REFERENCE_URL,
            "reference_note": "Use the linked common-disease guide to compare visible symptoms; it is not an automated diagnosis.",
        }

    pixels = np.asarray(pil_image.convert("RGB").resize((224, 224)), dtype=np.float32)
    batch = tf.keras.applications.efficientnet.preprocess_input(pixels)[None, ...]
    probabilities = np.asarray(model.predict(batch, verbose=0)[0], dtype=np.float32)
    index = int(np.argmax(probabilities))
    if index >= len(labels):
        raise RuntimeError("The number of model outputs does not match the labels file.")
    return {
        "label": labels[index],
        "confidence": round(float(probabilities[index]) * 100, 1),
        "mode": "EfficientNet image classifier",
        "next_steps": "Inspect affected plants and confirm the diagnosis with an agronomist.",
        "safety": "No pesticide recommendation is generated.",
        "reference_url": DISEASE_REFERENCE_URL,
        "reference_note": "Use the linked common-disease guide to compare visible symptoms; it is not an automated diagnosis.",
    }
async def weather(location: str, latitude: float | None = None, longitude: float | None = None) -> dict:
    if settings.open_meteo_enabled:
        try:
            async with httpx.AsyncClient(timeout=6) as client:
                if latitude is None or longitude is None:
                    geo = (await client.get(
                        "https://geocoding-api.open-meteo.com/v1/search",
                        params={"name": location, "count": 1},
                    )).json().get("results", [])
                    if not geo:
                        raise ValueError("Location was not found")
                    point = geo[0]
                    latitude, longitude = point["latitude"], point["longitude"]
                    display_location = point["name"]
                else:
                    display_location = "Current location"
                data = (await client.get(
                    "https://api.open-meteo.com/v1/forecast",
                    params={
                        "latitude": latitude,
                        "longitude": longitude,
                        "current": "temperature_2m,relative_humidity_2m,precipitation,weather_code",
                        "daily": "precipitation_sum,temperature_2m_max",
                        "timezone": "auto",
                    },
                )).json()
                return {
                    "source": "Open-Meteo",
                    "location": display_location,
                    "latitude": latitude,
                    "longitude": longitude,
                    "current": data.get("current", {}),
                    "daily": data.get("daily", {}),
                    "simulated": False,
                }
        except Exception: pass
    return {
        "source": "local demo fallback",
        "location": "Current location" if latitude is not None and longitude is not None else location,
        "current": {"temperature_2m": 29, "relative_humidity_2m": 68, "precipitation": 0},
        "daily": {"precipitation_sum": [2, 5, 0], "temperature_2m_max": [31, 32, 30]},
        "simulated": True,
    }

def _html_text(value: str) -> str:
    return re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", value)).strip()

async def tamilnadu_vegetable_prices() -> dict:
    source_url = "https://vegetablemarketprice.com/market/tamilnadu/today"
    try:
        async with httpx.AsyncClient(
            timeout=8,
            follow_redirects=True,
            headers={"User-Agent": "AgriMind-AI/1.0 market-price reader"},
        ) as client:
            response = await client.get(source_url)
            response.raise_for_status()
        html = response.text
        date_match = re.search(r'id="todayVegetableTableContainer"[^>]*data-current-date="([^"]+)"', html)
        rows = []
        for row in re.findall(r'<tr[^>]*class="todayVegetableTableRows"[^>]*>(.*?)</tr>', html, re.S):
            cells = [_html_text(cell) for cell in re.findall(r"<td[^>]*>(.*?)</td>", row, re.S)]
            if len(cells) >= 5:
                rows.append({
                    "name": cells[1],
                    "price": cells[2],
                    "retail_price": cells[3],
                    "unit": cells[4],
                })
        if not rows:
            raise ValueError("The source returned no vegetable price rows")
        return {
            "available": True,
            "source": "VegetableMarketPrice.com",
            "source_url": source_url,
            "date": date_match.group(1) if date_match else None,
            "prices": rows,
            "disclaimer": "Prices are indicative and may vary by market, quality, location, and time of sale. Confirm the buyer's quote before dispatch.",
        }
    except (httpx.HTTPError, ValueError) as exc:
        return {
            "available": False,
            "source": "VegetableMarketPrice.com",
            "source_url": source_url,
            "date": None,
            "prices": [],
            "message": "Today's source prices are temporarily unavailable. Use local mandi or buyer quotes before selling.",
            "error_type": type(exc).__name__,
        }
def create_sensor_alerts(db: Session, reading: SensorReading):
    messages=[]
    if reading.soil_moisture < 28: messages.append(("high","Low soil moisture","Root-zone moisture is below the demo threshold. Inspect the field and irrigation lines."))
    if reading.temperature > 38: messages.append(("medium","Heat stress watch","Temperature is above the demo heat threshold. Consider heat-risk field checks."))
    for sev,title,msg in messages:
        db.add(Alert(farm_id=reading.farm_id,severity=sev,title=title,message=msg))
def local_rag(question: str, response_language: str = "auto") -> dict:
    from sklearn.feature_extraction.text import TfidfVectorizer
    docs=[]
    for p in (ROOT/"genai"/"knowledge_base").glob("*.md"):
        docs.append((p.stem,p.read_text(encoding="utf-8")))
    if not docs: return {"answer":"The local knowledge base is empty.","sources":[],"mode":"local RAG"}
    query = question.lower()
    is_tamil = response_language == "ta" or (
        response_language == "auto" and bool(re.search(r"[\u0B80-\u0BFF]", question))
    )
    aliases = {
        "irrigation": {"rain", "rainfall", "weather", "forecast", "irrigation", "irrigate", "water", "moisture", "drought", "temperature", "மழை", "வானிலை", "நீர்ப்பாசனம்", "தண்ணீர்", "ஈரப்பதம்", "வெப்பநிலை"},
        "soil": {"soil", "soil condition", "fertility", "npk", "nitrogen", "phosphorus", "potassium", "fertilizer", "ph", "மண்", "உரம்", "நைட்ரஜன்", "பாஸ்பரஸ்", "பொட்டாசியம்"},
        "disease_screening": {"disease", "leaf", "leaves", "pest", "symptom", "fungus", "fungal", "photo", "image", "நோய்", "இலை", "பூச்சி", "அறிகுறி", "புகைப்படம்"},
    }
    vectorizer=TfidfVectorizer(stop_words="english")
    matrix=vectorizer.fit_transform([d[1] for d in docs]+[question])
    scores=(matrix[:-1]@matrix[-1].T).toarray().ravel()
    for index, (name, _) in enumerate(docs):
        scores[index] += sum(0.12 for term in aliases.get(name, set()) if re.search(rf"\b{re.escape(term)}\b", query))
    i=int(scores.argmax())
    matched_topic = next((name for name, terms in aliases.items() if any(term in query for term in terms)), None)
    if matched_topic and is_tamil:
        tamil_answers = {
            "soil": "மண் மற்றும் உரம் பற்றிய வழிகாட்டல்:\n\nமுதலில் மண் பரிசோதனை செய்து pH, நைட்ரஜன், பாஸ்பரஸ், பொட்டாசியம் அளவுகளை உறுதி செய்யுங்கள். சென்சார் மதிப்புகளை மட்டும் வைத்து அதிக உரம் இட வேண்டாம். பயிரின் வயது, மண் ஈரப்பதம் மற்றும் உள்ளூர் வேளாண் அதிகாரியின் பரிந்துரையைப் பார்த்து உரமிடுங்கள்.",
            "irrigation": "நீர்ப்பாசனம் பற்றிய வழிகாட்டல்:\n\nமண் ஈரப்பதம் குறைவாக இருந்தால் வேர் பகுதியைச் சரிபார்த்து, மெதுவாகவும் ஆழமாகவும் நீர் பாய்ச்சுங்கள். மழை முன்னறிவிப்பு இருந்தால் நீர்ப்பாசனத்தைத் தள்ளிப்போடுங்கள். காலை அல்லது மாலை நேரம் சிறந்தது. நீர் தேங்கினால் வேர் நோய் ஏற்படலாம்.",
            "disease_screening": "இலை மற்றும் நோய் பரிசோதனை பற்றிய வழிகாட்டல்:\n\nதெளிவான இலைப் புகைப்படத்தைப் பதிவேற்றுங்கள். முடிவு ஒரு ஆரம்பகட்ட திரையிடல் மட்டுமே; உறுதியான நோயறிதல் அல்ல. பாதிக்கப்பட்ட செடியைத் தனிமைப்படுத்தி, இலைகளின் கீழ்ப்பகுதியையும் பூச்சிகளையும் பாருங்கள். மருந்து பயன்படுத்துவதற்கு முன் உள்ளூர் வேளாண் நிபுணரை அணுகுங்கள்.",
        }
        source = next((name for name, content in docs if matched_topic in name.lower()), docs[0][0])
        return {"answer": tamil_answers[matched_topic], "sources":[source], "mode":"local RAG · தமிழ்", "grounded":True}
    if matched_topic:
        english_answers = {
            "soil": "Soil and fertilizer guidance:\n\nStart with a soil test to confirm pH, nitrogen, phosphorus, and potassium. Do not apply extra fertilizer based only on sensor values. Consider crop age, soil moisture, and local agriculture guidance before applying nutrients.",
            "irrigation": "Irrigation guidance:\n\nIf soil moisture is low, inspect the root zone and irrigate slowly and deeply. Delay irrigation when rain is expected. Morning or evening is usually better. Avoid standing water because it can damage roots.",
            "disease_screening": "Leaf and disease screening guidance:\n\nUpload a clear leaf photograph. The result is an initial screening, not a confirmed diagnosis. Isolate affected plants and inspect the underside of leaves for pests. Consult a local agricultural expert before using any treatment.",
        }
        source = next((name for name, content in docs if matched_topic in name.lower()), docs[0][0])
        return {"answer": english_answers[matched_topic], "sources":[source], "mode":"local RAG", "grounded":True}
    if not matched_topic and max(scores) == 0:
        return {
            "answer": "மண், நீர்ப்பாசனம், மழை, பயிர் திட்டமிடல் அல்லது இலை அறிகுறிகள் பற்றி கேளுங்கள். பயிர் பெயர், வயது, மண் ஈரப்பதம் அல்லது புகைப்பட விவரங்களைச் சேர்த்தால் தெளிவான வழிகாட்டலை வழங்க முடியும்." if is_tamil else "I can help with soil condition, irrigation and rainfall, crop planning, or leaf-screening guidance. Please include the crop, field symptoms, or sensor values you want me to interpret.",
            "sources": [],
            "mode": "local RAG",
            "grounded": True,
        }
    if is_tamil:
        return {
            "answer": "இந்தக் கேள்விக்கான குறிப்பிட்ட தமிழ் வழிகாட்டல் உள்ளூர் அறிவுத் தளத்தில் இல்லை. "
            "பயிர், மண் ஈரப்பதம், மழை முன்னறிவிப்பு அல்லது அறிகுறிகள் பற்றிய கூடுதல் விவரங்களைத் தமிழில் வழங்குங்கள். "
            "முக்கிய முடிவுகளுக்கு உள்ளூர் வேளாண் நிபுணரை அணுகுங்கள்.",
            "sources": [],
            "mode": "local RAG",
            "grounded": True,
        }
    return {
        "answer": "I could not find a closely matching local guide. Please include the crop, "
        "soil moisture, rainfall forecast, or symptoms. Confirm consequential decisions with a qualified local agronomist.",
        "sources": [],
        "mode": "local RAG",
        "grounded": True,
    }

def _weather_context(data: dict) -> str:
    current = data.get("current", {})
    return (
        f"Weather location: {data.get('location', 'unknown')}\n"
        f"Temperature: {current.get('temperature_2m', 'unavailable')} °C\n"
        f"Relative humidity: {current.get('relative_humidity_2m', 'unavailable')}%\n"
        f"Precipitation: {current.get('precipitation', 'unavailable')} mm\n"
        f"Weather source: {data.get('source', 'unavailable')}"
    )

async def ai_assistant(
    question: str,
    response_language: str = "en",
    voice_language: str | None = None,
    location: str | None = None,
    latitude: float | None = None,
    longitude: float | None = None,
) -> dict:
    fallback = local_rag(question, response_language=response_language)
    voice_fallback = (
        local_rag(question, response_language=voice_language)
        if voice_language and voice_language != response_language
        else None
    )
    weather_data = await weather(
        location or "Coimbatore, India",
        latitude=latitude,
        longitude=longitude,
    )
    if not settings.bedrock_enabled:
        fallback["fallback_reason"] = "BEDROCK_ENABLED is false"
        fallback["weather_context"] = _weather_context(weather_data)
        if fallback["sources"]:
            current = weather_data.get("current", {})
            if response_language == "ta":
                fallback["answer"] += (
                    f"\n\nதற்போதைய வானிலை: {weather_data.get('location', 'தெரியவில்லை')}. "
                    f"வெப்பநிலை {current.get('temperature_2m', 'தெரியவில்லை')}°C, "
                    f"ஈரப்பதம் {current.get('relative_humidity_2m', 'தெரியவில்லை')}%, "
                    f"மழை {current.get('precipitation', 'தெரியவில்லை')} mm."
                )
            else:
                fallback["answer"] += f"\n\nCurrent weather context:\n{_weather_context(weather_data)}"
        if voice_fallback:
            fallback["voice_answer"] = voice_fallback["answer"]
            fallback["voice_language"] = voice_language
        return fallback

    try:
        import boto3
    except ImportError:
        fallback["mode"] = "local RAG fallback"
        fallback["fallback_reason"] = "boto3 is not installed"
        fallback["weather_context"] = _weather_context(weather_data)
        if voice_fallback:
            fallback["voice_answer"] = voice_fallback["answer"]
            fallback["voice_language"] = voice_language
        return fallback

    try:
        from botocore.exceptions import BotoCoreError, ClientError
        client = boto3.client("bedrock-runtime", region_name=settings.aws_region)
        response = await asyncio.to_thread(
            client.converse,
            modelId=settings.bedrock_model_id,
            system=[{"text": (
                "You are AgriMind AI, a cautious agricultural decision-support assistant. "
                "Use the supplied local guidance and live weather context. Give practical, "
                "concise steps, state uncertainty, and never prescribe pesticides or claim "
                "a diagnosis. Recommend a qualified local agronomist for consequential decisions. "
                "Respond entirely in English when the requested response language is en. "
                "Respond entirely in Tamil script when the requested response language is ta. "
                "Never mix the two languages. The requested response language is: "
                f"{response_language}."
            )}],
            messages=[{"role": "user", "content": [{"text": (
                f"Local guidance:\n{fallback['answer']}\n\n"
                f"Live weather:\n{_weather_context(weather_data)}\n\n"
                f"Farmer question:\n{question}\n\nRequested response language: {response_language}"
            )}]}],
            inferenceConfig={
                "maxTokens": settings.ai_max_tokens,
                "temperature": settings.ai_temperature,
            },
        )
        answer = response["output"]["message"]["content"][0]["text"]
        result = {
            "answer": answer,
            "sources": fallback["sources"] + [weather_data["source"]],
            "mode": f"AWS Bedrock ({settings.bedrock_model_id})",
            "grounded": True,
            "weather_context": _weather_context(weather_data),
        }
        if voice_fallback:
            result["voice_answer"] = voice_fallback["answer"]
            result["voice_language"] = voice_language
        return result
    except (ImportError, BotoCoreError, ClientError) as exc:
        fallback["mode"] = "local RAG fallback"
        fallback["fallback_reason"] = f"Bedrock request unavailable: {type(exc).__name__}"
        fallback["weather_context"] = _weather_context(weather_data)
        if voice_fallback:
            fallback["voice_answer"] = voice_fallback["answer"]
            fallback["voice_language"] = voice_language
        return fallback
