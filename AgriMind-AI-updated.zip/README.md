# AgriMind AI

AgriMind AI is a local-first smart agriculture platform for farm records, crop advice, irrigation planning, yield estimates, disease-screening demos, simulated IoT readings, weather, alerts, analytics, and a grounded farming assistant.

## What runs without paid services

The default setup uses SQLite, deterministic model fallbacks, a local TF-IDF knowledge base, simulated sensors, and Open-Meteo's public weather endpoint. The assistant can call AWS Bedrock Converse for real AI answers grounded in the local knowledge base and live weather; when Bedrock is disabled or unavailable it clearly falls back to local retrieval. AWS Bedrock, S3, Cognito, and real sensor MQTT are optional deployment integrations.

## Quick start

Prerequisites: Python 3.11+.

```bash
cd AgriMind-AI
python -m venv .venv
.venv\Scripts\activate
pip install -r backend/requirements.txt
copy .env.example .env
uvicorn backend.app.main:app --reload
```

Open `http://127.0.0.1:8000`. The seeded accounts are:

| Role | Email | Password |
| --- | --- | --- |
| Admin | admin@agrimind.local | Admin@123 |
| Farmer | farmer@agrimind.local | Farmer@123 |
| Agronomist | agronomist@agrimind.local | Agronomist@123 |

The API documentation is available at `/docs`.

## Docker

```bash
docker compose up --build
```

Data persists in the `agrimind-data` Docker volume. Copy `.env.example` to `.env` before enabling optional integrations.

## Main modules

| Area | Local behavior | Optional production integration |
| --- | --- | --- |
| Crop recommendation | Rule-backed model response with confidence | Trained scikit-learn model artifact |
| Yield and irrigation | Agronomy-inspired estimator | Trained regression artifacts |
| Fertilizer review | Nutrient-gap safety guidance | Soil-lab and local extension rules |
| Disease screening | Filename/demo classifier, safely labelled | TensorFlow EfficientNet model |
| Weather | Open-Meteo using browser location or farm location, with safe simulated fallback | Any weather provider adapter |
| GenAI assistant | TF-IDF retrieval with selected-language text responses and voice-language detection for Tamil/English | AWS Bedrock Converse API |
| Sensors | REST simulation endpoint | MQTT / AWS IoT Core bridge |
| Storage | Local upload directory | Amazon S3 |

## Project layout

```text
AgriMind-AI/
├── backend/                 FastAPI app, DB, services and API
├── frontend/                Responsive static dashboard
├── ml/                      Training scripts and sample CSV data
├── computer_vision/         EfficientNet training and inference adapters
├── genai/knowledge_base/    Local RAG source documents
├── iot/                     Sensor simulator and MQTT bridge example
├── aws/                     SAM template, Bedrock and deployment notes
├── docs/                    Architecture, report, API and viva notes
├── tests/                   API and service tests
└── docker-compose.yml
```

## Train optional models

The app works before training. To make trained artifacts, install `ml/requirements-training.txt` and run:

```bash
python ml/train_models.py
```

For the disease model, download a properly licensed plant-disease dataset, place it under `computer_vision/data/` with one folder per class, then run:

```bash
pip install -r computer_vision/requirements.txt
python computer_vision/train.py --data computer_vision/data
```

The disease feature never presents a clinical or pesticide prescription. It flags likely classes for qualified agricultural review.

## AWS deployment

The local Docker path is the recommended first demo. For AWS, configure the `aws/` variables and follow [aws/DEPLOYMENT.md](aws/DEPLOYMENT.md). The SAM template provides API Gateway, Lambda, DynamoDB, S3, and least-privilege Bedrock permissions. Verify regional availability, pricing, retention, data residency, and human review requirements before deployment.

## Tests

```bash
pytest -q
```

## Safety and limitations

Predictions are decision support, not agronomy, medical, legal, or pesticide advice. Validate recommendations against soil tests, local weather, crop stage, local regulations, and a certified agronomist. Demo data and calculated values are synthetic.
