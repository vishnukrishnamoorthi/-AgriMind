# AgriMind AI

AgriMind AI is a local-first smart agriculture platform for farm records, crop advice, irrigation planning, yield estimates, disease-screening demos, simulated IoT readings, weather, alerts, analytics, and a grounded farming assistant.

## What runs without paid services

The default setup uses SQLite, deterministic model fallbacks, a local TF-IDF knowledge base, simulated sensors, and Open-Meteo's public weather endpoint. The assistant uses Groq Chat Completions with the configured open-weight model and supplies the local knowledge base as additional agricultural context. AWS Bedrock, S3, Cognito, and real sensor MQTT remain optional deployment integrations.

## Quick start

Prerequisites: Python 3.11+.

```bash
cd AgriMind-AI
python -m venv .venv
.venv\Scripts\activate
pip install -r backend/requirements.txt
copy .env.example .env
# Set GROQ_API_KEY and GROQ_MODEL in .env before using the assistant.
uvicorn backend.app.main:app --reload
```

Open `http://127.0.0.1:8000`. The seeded accounts are:

| Role | Email | Password |
| --- | --- | --- |
| Admin | admin@agrimind.local | Admin@123 |
| Farmer | farmer@agrimind.local | Farmer@123 |
| Agronomist | agronomist@agrimind.local | Agronomist@123 |

The API documentation is available at `/docs`.

## Docker

```bash
docker compose up --build
```

Data persists in the `agrimind-data` Docker volume. Copy `.env.example` to `.env` before enabling optional integrations.

## Main modules

| Area | Local behavior | Optional production integration |
| --- | --- | --- |
| Crop recommendation | Rule-backed model response with confidence | Trained scikit-learn model artifact |
| Yield and irrigation | Agronomy-inspired estimator | Trained regression artifacts |
| Fertilizer review | Nutrient-gap safety guidance | Soil-lab and local extension rules |
| Disease screening | Filename/demo classifier, safely labelled | TensorFlow EfficientNet model |
| Weather | Open-Meteo using browser location or farm location, with safe simulated fallback | Any weather provider adapter |
| GenAI assistant | Groq Chat Completions with bounded per-user context and local agricultural grounding | Configurable Groq open-weight model |
| Sensors | REST simulation endpoint | MQTT / AWS IoT Core bridge |
| Storage | Local upload directory | Amazon S3 |

## Project layout

```text
AgriMind-AI/
├── backend/                 FastAPI app, DB, services and API
├── frontend/                Responsive static dashboard
├── ml/                      Training scripts and sample CSV data
├── computer_vision/         EfficientNet training and inference adapters
├── genai/knowledge_base/    Local RAG source documents
├── iot/                     Sensor simulator and MQTT bridge example
├── aws/                     SAM template, Bedrock and deployment notes
├── docs/                    Architecture, report, API and viva notes
├── tests/                   API and service tests
└── docker-compose.yml
```

## Train optional models

The app works before training. To make trained artifacts, install `ml/requirements-training.txt` and run:

```bash
python ml/train_models.py
```

For the disease model, download a properly licensed plant-disease dataset, place it under `computer_vision/data/` with one folder per class, then run:

```bash
pip install -r computer_vision/requirements.txt
python computer_vision/train.py --data computer_vision/data
```

The disease feature never presents a clinical or pesticide prescription. It flags likely classes for qualified agricultural review.

## AWS deployment

The local Docker path is the recommended first demo. For AWS, configure the `aws/` variables and follow [aws/DEPLOYMENT.md](aws/DEPLOYMENT.md). The SAM template provides API Gateway, Lambda, DynamoDB, S3, and least-privilege Bedrock permissions. Verify regional availability, pricing, retention, data residency, and human review requirements before deployment.

## Tests

```bash
pytest -q
```

## Groq assistant configuration

Create an API key in the [Groq Console](https://console.groq.com/keys).
Groq's current production model documentation lists
`openai/gpt-oss-120b` as an active open-weight model. The integration uses the
documented Groq Chat Completions endpoint at
`https://api.groq.com/openai/v1/chat/completions`; verify model availability
against the [Groq supported-models page](https://console.groq.com/docs/models)
before changing `GROQ_MODEL`.
Copy it only into the server-side `.env` file or the hosting platform's secret
environment-variable store:

```text
GROQ_API_KEY=your-server-side-key
GROQ_MODEL=openai/gpt-oss-120b
GROQ_TIMEOUT_SECONDS=30
GROQ_MAX_TOKENS=700
GROQ_RATE_LIMIT_PER_MINUTE=20
```

Never put the key in frontend files, commit it to Git, or return it from an API
endpoint. Groq usage and limits depend on the selected account and model; API
access is not assumed to be unlimited or free. The assistant returns explicit
errors when the key is missing, invalid, rate-limited, over quota, or unavailable.

For deployment, configure the same variables as encrypted server-side
environment variables or platform secrets (for example, the container service,
VM service manager, or CI/CD deployment secret store). Do not place
`GROQ_API_KEY` in a browser build, Docker image layer, repository variable
visible to pull requests, or client-side configuration endpoint.

### Render

In the Render service dashboard, open **Environment → Environment Variables**
and add:

```text
GROQ_API_KEY=your_groq_api_key
GROQ_MODEL=openai/gpt-oss-120b
GROQ_TIMEOUT_SECONDS=30
GROQ_MAX_TOKENS=700
GROQ_RATE_LIMIT_PER_MINUTE=20
```

Save the changes and trigger a new deploy or restart. Keep the key as a
protected Render secret and never add it to the repository.

## Safety and limitations

Predictions are decision support, not agronomy, medical, legal, or pesticide advice. Validate recommendations against soil tests, local weather, crop stage, local regulations, and a certified agronomist. Demo data and calculated values are synthetic.
