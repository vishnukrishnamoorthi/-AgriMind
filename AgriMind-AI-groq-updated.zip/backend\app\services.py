"""Prediction, weather, alert, and Groq assistant services."""
import io, json, math, random, time
from collections import defaultdict, deque
from datetime import datetime
from functools import lru_cache
from pathlib import Path
import httpx
from sqlalchemy.orm import Session
from .config import ROOT, settings
from .models import Alert, SensorReading

_assistant_history: dict[int, deque[dict[str, str]]] = defaultdict(lambda: deque(maxlen=8))
_assistant_requests: dict[int, deque[float]] = defaultdict(deque)
GROQ_CHAT_URL = "https://api.groq.com/openai/v1/chat/completions"

class AssistantServiceError(Exception):
    def __init__(self, status_code: int, message: str):
        super().__init__(message)
        self.status_code = status_code
        self.message = message

CROP_PROFILES = {
    "Rice": {"n": 90, "p": 42, "k": 43, "temp": 27, "rain": 190},
    "Maize": {"n": 110, "p": 50, "k": 45, "temp": 24, "rain": 95},
    "Cotton": {"n": 85, "p": 35, "k": 40, "temp": 29, "rain": 75},
    "Chickpea": {"n": 25, "p": 55, "k": 45, "temp": 22, "rain": 55},
    "Banana": {"n": 120, "p": 45, "k": 70, "temp": 28, "rain": 140},
}
def crop_recommendation(x: dict) -> dict:
    scores = []
    for crop, p in CROP_PROFILES.items():
        d = abs(x["nitrogen"]-p["n"])/p["n"] + abs(x["phosphorus"]-p["p"])/p["p"] + abs(x["potassium"]-p["k"])/p["k"] + abs(x["temperature"]-p["temp"])/15 + abs(x["rainfall"]-p["rain"])/200 + abs(x["ph"]-6.5)/7
        scores.append((crop, max(0.05, 1/(1+d))))
    scores.sort(key=lambda v: v[1], reverse=True); total = sum(s for _, s in scores)
    ranked = [{"crop": c, "confidence": round(s/total*100, 1)} for c,s in scores]
    return {"recommended_crop": ranked[0]["crop"], "confidence": ranked[0]["confidence"], "alternatives": ranked[1:3], "mode": "local rule model", "disclaimer": "Validate with local crop calendars, soil tests, water availability, and an agronomist."}
def yield_prediction(x: dict) -> dict:
    base = {"rice": 2.7, "maize": 2.3, "cotton": 0.8, "banana": 12.0}.get(x["crop"].lower(), 1.8)
    nutrition = min(1.15, 0.75 + x["nitrogen"]/300); water = min(1.1, 0.65+x["rainfall"]/500+x["soil_moisture"]/250)
    heat = max(.6, 1-abs(x["temperature"]-27)/40); per_acre = round(base*nutrition*water*heat, 2)
    return {"yield_tonnes_per_acre": per_acre, "total_tonnes": round(per_acre*x["area_acres"],2), "confidence_band": "±25%", "drivers": ["synthetic baseline", "nutrient estimate", "water and temperature proxy"], "mode":"local estimator"}
def irrigation_plan(x: dict) -> dict:
    target = {"rice": 65, "banana": 60, "cotton": 48, "maize": 50}.get(x["crop"].lower(), 50)
    deficit = max(0, target - x["soil_moisture"])
    heat_factor = max(0.7, min(1.4, 1+(x["temperature"]-25)/50-(x["humidity"]-55)/200))
    rain_credit = min(deficit, x["rainfall_forecast"]*0.6)
    litres = round(max(0, (deficit-rain_credit)*45*x["area_acres"]*heat_factor))
    urgency = "high" if deficit > 20 and x["rainfall_forecast"] < 4 else "medium" if deficit > 8 else "low"
    return {"irrigation_litres": litres, "urgency": urgency, "target_moisture": target, "suggested_window": "early morning", "note": "Check root-zone moisture and irrigation-system flow before applying water."}
def fertilizer_review(x: dict) -> dict:
    gaps = {"nitrogen": max(0,90-x["nitrogen"]), "phosphorus": max(0,42-x["phosphorus"]), "potassium": max(0,43-x["potassium"])}
    needs = [k for k,v in gaps.items() if v>10]
    return {"nutrient_gaps": gaps, "priority": needs or ["No major gap in demo thresholds"], "guidance": "Use a certified soil test and local extension recommendation to determine product, dose, timing, and legal restrictions. Do not treat this screen as a fertilizer prescription."}
@lru_cache(maxsize=1)
def _load_disease_model():
    try:
        import tensorflow as tf
    except ImportError as exc:
        raise RuntimeError("TensorFlow is not installed. Install computer_vision/requirements.txt and train the disease model.") from exc

    model_path = Path(settings.model_dir)
    if not model_path.is_absolute():
        model_path = ROOT / model_path
    if model_path.is_dir():
        model_path /= "disease_model.keras"
    if not model_path.exists():
        raise RuntimeError(f"Disease model not found at {model_path}. Train computer_vision/train.py first.")

    labels_path = Path(f"{model_path}.labels.txt")
    if not labels_path.exists():
        raise RuntimeError(f"Disease model labels not found at {labels_path}.")
    labels = [label.strip() for label in labels_path.read_text(encoding="utf-8").splitlines() if label.strip()]
    if not labels:
        raise RuntimeError(f"Disease model labels file is empty: {labels_path}.")
    return tf.keras.models.load_model(model_path), labels


def disease_screen(image) -> dict:
    try:
        import numpy as np
        from PIL import Image, UnidentifiedImageError
    except ImportError as exc:
        raise RuntimeError("NumPy and Pillow are required for image screening.") from exc

    if isinstance(image, Image.Image):
        pil_image = image
    else:
        try:
            pil_image = Image.open(io.BytesIO(image))
        except (TypeError, UnidentifiedImageError, OSError) as exc:
            raise ValueError("The uploaded file is not a valid image.") from exc

    try:
        import tensorflow as tf
        model, labels = _load_disease_model()
    except (ImportError, RuntimeError):
        return {
            "label": "Model unavailable: image received",
            "confidence": None,
            "mode": "demo upload validation",
            "next_steps": "Train the EfficientNet model and repeat the screening before making crop-management decisions.",
            "safety": "This upload was validated, but no disease classification was made and no pesticide recommendation is generated.",
            "reference_url": "https://earthsally.com/disease-control/common-plant-diseases.html",
            "reference_note": "Use a common-disease guide only to compare visible symptoms; it is not an automated diagnosis.",
        }

    pixels = np.asarray(pil_image.convert("RGB").resize((224, 224)), dtype=np.float32)
    batch = tf.keras.applications.efficientnet.preprocess_input(pixels)[None, ...]
    probabilities = np.asarray(model.predict(batch, verbose=0)[0], dtype=np.float32)
    index = int(np.argmax(probabilities))
    if index >= len(labels):
        raise RuntimeError("The number of model outputs does not match the labels file.")
    return {
        "label": labels[index],
        "confidence": round(float(probabilities[index]) * 100, 1),
        "mode": "EfficientNet image classifier",
        "next_steps": "Inspect affected plants and confirm the diagnosis with an agronomist.",
        "safety": "No pesticide recommendation is generated.",
    }
async def weather(location: str, latitude: float | None = None, longitude: float | None = None) -> dict:
    if settings.open_meteo_enabled:
        try:
            async with httpx.AsyncClient(timeout=6) as client:
                if latitude is None or longitude is None:
                    geo = (await client.get("https://geocoding-api.open-meteo.com/v1/search", params={"name":location,"count":1})).json().get("results",[])
                    if not geo:
                        raise ValueError("Location was not found")
                    latitude, longitude, location = geo[0]["latitude"], geo[0]["longitude"], geo[0]["name"]
                data = (await client.get("https://api.open-meteo.com/v1/forecast", params={
                    "latitude": latitude, "longitude": longitude,
                    "current": "temperature_2m,relative_humidity_2m,precipitation,weather_code",
                    "daily": "precipitation_sum,temperature_2m_max", "timezone": "auto",
                })).json()
                return {"source": "Open-Meteo", "location": "Current location" if location == "Coimbatore, India" and latitude is not None else location, "current": data.get("current", {}), "daily": data.get("daily", {}), "simulated": False}
        except Exception: pass
    return {"source":"local demo fallback","location":location,"current":{"temperature_2m":29,"relative_humidity_2m":68,"precipitation":0},"daily":{"precipitation_sum":[2,5,0],"temperature_2m_max":[31,32,30]},"simulated":True}
def create_sensor_alerts(db: Session, reading: SensorReading):
    messages=[]
    if reading.soil_moisture < 28: messages.append(("high","Low soil moisture","Root-zone moisture is below the demo threshold. Inspect the field and irrigation lines."))
    if reading.temperature > 38: messages.append(("medium","Heat stress watch","Temperature is above the demo heat threshold. Consider heat-risk field checks."))
    for sev,title,msg in messages:
        db.add(Alert(farm_id=reading.farm_id,severity=sev,title=title,message=msg))

def live_crop_analysis(reading: dict, crop: str) -> dict:
    signals = []
    score = 100
    moisture = reading["soil_moisture"]
    temperature = reading["temperature"]
    humidity = reading["humidity"]
    if moisture < 28:
        score -= 35
        signals.append({"level": "high", "label": "Moisture is low", "detail": "Inspect root-zone moisture and irrigation lines."})
    elif moisture < 40:
        score -= 15
        signals.append({"level": "medium", "label": "Moisture is trending low", "detail": "Recheck the field before the next irrigation window."})
    if temperature > 38:
        score -= 25
        signals.append({"level": "medium", "label": "Heat stress risk", "detail": "Schedule a field check during the cooler part of the day."})
    if humidity > 85:
        score -= 10
        signals.append({"level": "low", "label": "Humidity is high", "detail": "Increase scouting for fungal symptoms."})
    status = "Healthy" if score >= 80 else "Watch" if score >= 55 else "Action needed"
    return {
        "crop": crop, "status": status, "health_score": score,
        "recommendation": "Conditions look stable. Continue routine monitoring." if status == "Healthy" else "Prioritise a field inspection and confirm the next irrigation decision.",
        "signals": signals, "reading": reading,
    }

async def tamilnadu_vegetable_prices() -> dict:
    vegetables = [
        {"name": "Tomato", "unit": "kg", "quality": "Indicative retail range"},
        {"name": "Onion", "unit": "kg", "quality": "Indicative retail range"},
        {"name": "Brinjal", "unit": "kg", "quality": "Indicative retail range"},
    ]
    return {
        "available": False,
        "vegetables": vegetables,
        "prices": [],
        "terms": [
            ("Payment basis", "Confirm whether the buyer price is per kg, crate, bundle, or lot."),
            ("Payment timing", "Record when payment is due and retain a written receipt."),
        ],
        "disclaimer": "Indicative information only. Confirm current prices with local mandi or buyer quotes.",
    }
def local_rag(question: str, response_language: str = "en") -> dict:
    from sklearn.feature_extraction.text import TfidfVectorizer
    docs=[]
    for p in (ROOT/"genai"/"knowledge_base").glob("*.md"):
        docs.append((p.stem,p.read_text(encoding="utf-8")))
    if not docs: return {"answer":"The local knowledge base is empty.","sources":[],"mode":"local RAG"}
    vectorizer=TfidfVectorizer(stop_words="english"); matrix=vectorizer.fit_transform([d[1] for d in docs]+[question]); scores=(matrix[:-1]@matrix[-1].T).toarray().ravel(); i=int(scores.argmax())
    excerpt=docs[i][1][:900].replace("#"," ")
    return {"answer":f"Based on the local farming guidance: {excerpt}\n\nFor field-specific action, confirm with a qualified local agronomist.","sources":[docs[i][0]],"mode":"local RAG","grounded":True}

def _weather_context(data: dict) -> str:
    current = data.get("current", {})
    return (
        f"Weather location: {data.get('location', 'unknown')}\n"
        f"Temperature: {current.get('temperature_2m', 'unavailable')} °C\n"
        f"Relative humidity: {current.get('relative_humidity_2m', 'unavailable')}%\n"
        f"Precipitation: {current.get('precipitation', 'unavailable')} mm\n"
        f"Weather source: {data.get('source', 'unavailable')}"
    )

async def ai_assistant(
    question: str,
    response_language: str = "en",
    voice_language: str | None = None,
    user_id: int | None = None,
    location: str | None = None,
    latitude: float | None = None,
    longitude: float | None = None,
) -> dict:
    if not settings.groq_api_key:
        raise AssistantServiceError(503, "The AI assistant is not configured. Set GROQ_API_KEY on the server.")
    if user_id is None:
        raise AssistantServiceError(500, "The AI assistant session is unavailable.")
    now = time.monotonic()
    requests = _assistant_requests[user_id]
    while requests and now - requests[0] >= 60:
        requests.popleft()
    if len(requests) >= settings.groq_rate_limit_per_minute:
        raise AssistantServiceError(429, "The AI assistant is temporarily rate-limited. Please try again shortly.")
    requests.append(now)

    context = local_rag(question)
    weather_data = await weather(location or "Coimbatore, India", latitude=latitude, longitude=longitude)
    weather_context = _weather_context(weather_data)
    system = (
        "You are AgriMind AI, a general-purpose assistant with agricultural expertise. "
        "Answer general, technical, project, and agriculture questions naturally. Be concise "
        "unless detail is requested, ask clarifying questions when needed, and do not invent "
        "current facts. For weather, storms, news, or other changing facts, use only supplied "
        "live data and clearly say when it is unavailable. For agricultural recommendations, "
        "be cautious and recommend local validation for consequential decisions. Use the "
        "supplied local knowledge-base context as additional domain guidance. Reply entirely "
        "in English when the requested language marker is en, or entirely in natural Tamil "
        f"script when it is ta. Never let voice_language change that language. "
        f"Requested language marker: {response_language}."
    )
    messages = list(_assistant_history[user_id]) + [{
        "role": "user",
        "content": (
            f"Local knowledge-base context:\n{context['answer']}\n\n"
            f"Live weather context:\n{weather_context}\n\n"
            f"User question:\n{question}"
        ),
    }]
    async def generate(language: str, input_messages: list[dict[str, str]]) -> str:
        language_system = system.replace(
            f"Requested language marker: {response_language}.",
            f"Requested language marker: {language}.",
        )
        return await _groq_chat_completion(language_system, input_messages)

    answer = await generate(response_language, messages)
    voice_answer = None
    if voice_language and voice_language != response_language:
        voice_answer = await generate(
            voice_language,
            messages + [{
                "role": "user",
                "content": (
                    "Provide the same answer you just gave to the user's question in "
                    f"{'natural Tamil script' if voice_language == 'ta' else 'English'}."
                ),
            }],
        )

    _assistant_history[user_id].extend([
        {"role": "user", "content": question},
        {"role": "assistant", "content": answer},
    ])
    result = {
        "answer": answer,
        "sources": context["sources"] + [weather_data.get("source", "weather unavailable")],
        "mode": f"Groq Chat Completions ({settings.groq_model})",
        "grounded": True,
        "weather_context": weather_context,
    }
    if voice_answer is not None:
        result["voice_answer"] = voice_answer
        result["voice_language"] = voice_language
    return result

async def _groq_chat_completion(system: str, messages: list[dict[str, str]]) -> str:
    payload = {
        "model": settings.groq_model,
        "messages": [{"role": "system", "content": system}, *messages],
        "max_tokens": settings.groq_max_tokens,
        "temperature": 0.2,
    }
    try:
        async with httpx.AsyncClient(timeout=settings.groq_timeout_seconds) as client:
            response = await client.post(
                GROQ_CHAT_URL,
                headers={
                    "Authorization": f"Bearer {settings.groq_api_key}",
                    "Content-Type": "application/json",
                },
                json=payload,
            )
    except httpx.TimeoutException as exc:
        raise AssistantServiceError(504, "The AI assistant could not be reached in time. Please try again.") from exc
    except httpx.RequestError as exc:
        raise AssistantServiceError(504, "The AI assistant service could not be reached. Please try again.") from exc

    if response.status_code in {401, 403}:
        raise AssistantServiceError(502, "The Groq API key was rejected.")
    if response.status_code == 429:
        raise AssistantServiceError(429, "The AI assistant is temporarily unavailable due to Groq API limits or quota.")
    if response.status_code in {400, 404}:
        raise AssistantServiceError(502, "The configured Groq model or request was rejected.")
    if response.status_code >= 500:
        raise AssistantServiceError(502, "The Groq AI service is temporarily unavailable.")
    if response.status_code >= 400:
        raise AssistantServiceError(502, "The Groq AI request could not be completed.")

    try:
        answer = response.json()["choices"][0]["message"]["content"].strip()
    except (KeyError, IndexError, TypeError, AttributeError, ValueError) as exc:
        raise AssistantServiceError(502, "The AI assistant returned an invalid response.") from exc
    if not answer:
        raise AssistantServiceError(502, "The AI assistant returned an empty response.")
    return answer
