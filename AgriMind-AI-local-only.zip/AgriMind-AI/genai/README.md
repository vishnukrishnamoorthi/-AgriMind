# GenAI and RAG

`backend/app/services.py` provides a bundled Markdown retrieval context and an AWS Bedrock Converse adapter. Set `BEDROCK_ENABLED=true`, configure AWS credentials and model access, and review prompt-injection controls, data classification, logging, consent, human escalation, and regional service availability before deployment. When Bedrock is disabled or unavailable, the API returns the sourced local response and identifies the fallback mode. Never send private farm records to a third-party model without a defined policy and farmer consent.
