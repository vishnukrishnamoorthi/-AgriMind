# Leaf image screening limitations

An image classifier can confuse disease, nutrient deficiency, pest damage, dust, lighting, and physical injury. Take several focused photos of both sides of representative leaves in natural light. Include crop species, crop stage, field pattern, weather history, and symptoms for an agronomist. Treat model output as a screening signal only. Confirm locally before crop treatment, particularly before applying regulated products.
