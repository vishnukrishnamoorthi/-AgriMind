# Irrigation interpretation guide

Soil moisture is a local measurement, not a universal irrigation command. Confirm sensor placement, root-zone depth, crop stage, soil texture, irrigation efficiency, and expected rain. A falling moisture value can indicate water use, faulty sensor placement, or a broken irrigation line. Inspect the field before acting. Prefer early-morning irrigation when local crop guidance and water availability support it. Avoid overwatering, which can reduce root oxygen and increase disease risk.
