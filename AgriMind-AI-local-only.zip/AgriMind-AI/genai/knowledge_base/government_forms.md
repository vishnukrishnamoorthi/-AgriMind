# Government forms and schemes

This local guide contains process guidance only. It does not verify live scheme
eligibility, deadlines, fees, required documents, or application status.

For a government form, certificate, or scheme application:

1. Identify the responsible official department or service portal.
2. Open the current notice or form published by that authority.
3. Check eligibility, required documents, fee, submission method, and deadline.
4. Submit through the official portal or designated office.
5. Save the acknowledgement or application number.
6. Contact the department directly if a document or status is unclear.

Common document categories may include identity, address, bank, income, land,
education, or caste records, but the exact list varies by service. Confirm it
from the current official notice rather than relying on this guide.
