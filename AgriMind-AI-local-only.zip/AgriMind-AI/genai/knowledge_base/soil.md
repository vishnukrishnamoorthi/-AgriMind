# Soil and fertilizer guidance

NPK values only describe a portion of soil fertility. Use an accredited soil test for pH, organic matter, salinity, micronutrients, and nutrient availability. Match any fertilizer plan to crop stage, expected yield, prior amendments, local extension guidance, and local regulations. Keep fertilizers away from waterways and use the labelled product instructions. This knowledge base does not provide a product dose or pesticide recommendation.
