# Technology and computer basics

For a computer problem, record the exact error, what changed before it
appeared, the operating system, and the steps that reproduce it. Back up
important data before repairs. Prefer official documentation and trusted
software sources. Do not run commands or share passwords, keys, or personal
data unless you understand their purpose.
