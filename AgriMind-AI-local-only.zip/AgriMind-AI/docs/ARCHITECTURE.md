# AgriMind AI architecture

```mermaid
flowchart LR
  Farmer[Farmer or Agronomist] --> Web[Responsive web dashboard]
  Web --> API[FastAPI API]
  API --> Auth[JWT and role checks]
  API --> DB[(SQLite local demo)]
  API --> Models[Local prediction services]
  API --> RAG[TF IDF knowledge base and Bedrock Converse]
  API --> Weather[Open Meteo optional, farm or browser location]
  Simulator[IoT simulator or MQTT bridge] --> API
  API -. production option .-> AWS[AWS API Gateway Lambda S3 DynamoDB Bedrock]
```

## Data flow

1. A user signs in and receives a short-lived JWT.
2. A sensor or simulator submits a validated reading for an authorized farm.
3. Alert rules evaluate moisture and heat thresholds and create actionable alerts.
4. The live crop-analysis endpoint evaluates the newest authorized reading into a transparent health score, status, risk signals, and a cautious next action. The dashboard refreshes this signal every 15 seconds.
5. Prediction endpoints record non-sensitive decision-support outputs for auditability.
6. The assistant retrieves bundled guidance, adds live weather context, and can call Bedrock Converse for a real AI answer. If Bedrock is disabled or unavailable, it returns the sourced local response and an explicit fallback mode.

## Role matrix

| Action | Farmer | Agronomist | Admin |
| --- | --- | --- | --- |
| Own farm records | Yes | Yes | Yes |
| Other farmers' farm records | No | Yes | Yes |
| Model guidance | Yes | Yes | Yes |
| User listing | No | No | Yes |

## Trust boundaries

The browser is untrusted. The API authenticates every protected request and checks farm ownership. Sensor values are schema-validated but should also be authenticated at the device gateway in production. Browser geolocation is optional and is validated by the API before it is sent to Open-Meteo. Weather and Bedrock are external dependencies; their outages fall back locally and their data must be governed before use.
