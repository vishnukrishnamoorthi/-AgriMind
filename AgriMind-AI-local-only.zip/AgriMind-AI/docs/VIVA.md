# AgriMind AI Viva Preparation

## One minute introduction

AgriMind AI is a full-stack smart agriculture decision-support system. A farmer logs into a dashboard, manages farms, receives sensor and weather observations, gets crop and irrigation guidance, sees alerts, and can ask a sourced farming assistant. The local demo uses SQLite, simulated IoT, deterministic ML fallbacks, and a local RAG knowledge base. AWS components are optional and documented for production deployment.

## Likely questions

**Why FastAPI?** It provides typed validation, automatic OpenAPI documentation, asynchronous support for external adapters, and a lightweight Python path for ML integration.

**How is authentication secured?** Passwords are bcrypt-hashed. The API issues a signed JWT and checks the token and farm ownership on protected endpoints. Production should use Cognito, rotation, HTTPS, and a managed secret.

**Is the model accurate?** The included model data is synthetic, so it is for demonstrating the pipeline only. Accuracy needs geographically relevant, licensed data, held-out evaluation, model cards, drift checks, and agronomist review.

**Why use RAG?** Retrieval limits answers to approved local knowledge and exposes the document source. For a production Bedrock integration, the system should add access control, prompt-injection defenses, safety filters, logs, and human escalation.

**How would you connect sensors?** A device would publish TLS-protected MQTT data through AWS IoT Core. A schema-validation service would normalize it before database storage and alert evaluation.

**What makes this cloud-ready?** Docker packaging, environment-driven configuration, a SAM template, API separation, S3 and Bedrock hooks, plus explicit production hardening instructions.

## Demo flow

1. Sign in as the demo farmer.
2. Open Overview and explain seeded readings and weather source.
3. Simulate a sensor value from My farms and show alerts.
4. Use Crop advisor and Irrigation planner.
5. Upload a sample image and explain demo versus trained model mode.
6. Ask the assistant about low soil moisture and point out the source.
7. Show `aws/template.yaml` and distinguish local from production deployment.
