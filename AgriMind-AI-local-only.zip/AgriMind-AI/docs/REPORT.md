# AgriMind AI Project Report

## Abstract

AgriMind AI is a local-first smart agriculture decision-support application. It combines farm records, soil and weather inputs, simulated IoT telemetry, simple predictive models, alert rules, a leaf-screening workflow, and a retrieval-grounded farming assistant. The design intentionally keeps a complete demonstration runnable without paid cloud services while showing a migration path to AWS.

## Problem statement

Small and medium farms often receive fragmented signals from weather, irrigation, soil results, and crop health observations. The project brings these signals into one authenticated workspace. It does not automate agronomic decisions or chemical treatment.

## Objectives

- Record farms and validated sensor readings.
- Surface moisture and heat alerts.
- Offer explainable crop, yield, irrigation, and nutrient-gap estimates.
- Demonstrate a safe image-screening workflow.
- Provide a cited local RAG assistant.
- Support AWS deployment after a production readiness review.

## Implementation

The backend uses FastAPI, SQLAlchemy, SQLite, JWT authentication, and role checks. The browser interface uses HTML, CSS, and JavaScript without a paid frontend platform. Local service functions provide deterministic estimators and an Open-Meteo adapter with a simulated fallback. The RAG fallback uses TF-IDF across included Markdown guidance. Training scripts build Random Forest artifacts from synthetic sample data. A separate EfficientNetB0 transfer-learning script accepts a curated plant-disease dataset.

## Results and demonstration

The seeded farmer can sign in, view a demo farm, simulate readings, create alerts, inspect weather, generate crop and irrigation guidance, upload a leaf image for a clearly labelled demo screen, and query the grounded assistant. The automated API test suite exercises health, authentication, farm authorization, prediction, and sensor ingestion.

## Limitations

The training data is synthetic and must not be used to make real recommendations. The baseline disease screen uses the file name when no trained model is enabled. Open-Meteo availability depends on network access. SQLite, seeded credentials, wildcard CORS, and local uploads are only appropriate for a local demo.

## Future work

Future versions can add lab-result ingestion, multilingual support, proper model monitoring, agronomist review queues, encrypted media storage, IoT device certificates, real market-price feeds, satellite-derived vegetation indices, and a reviewed Bedrock knowledge-base adapter.

## Conclusion

This deliverable provides a runnable end-to-end project and an explicit boundary between simulated course-demo features and cloud-dependent production capabilities. Its architecture gives a clear foundation for a portfolio demonstration and future AWS implementation.
