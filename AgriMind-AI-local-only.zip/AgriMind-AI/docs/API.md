# API guide

All protected endpoints require `Authorization: Bearer <token>`. Interactive API documentation runs at `/docs`.

| Endpoint | Purpose |
| --- | --- |
| `POST /api/auth/login` | Sign in and receive JWT |
| `GET, POST /api/farms` | Read or create farms |
| `POST /api/farms/{id}/sensors` | Ingest a validated sensor reading |
| `POST /api/farms/{id}/simulate-sensor` | Create a clearly simulated reading |
| `POST /api/predictions/crop` | Crop recommendation |
| `POST /api/predictions/yield` | Yield estimate |
| `POST /api/predictions/irrigation` | Irrigation plan |
| `POST /api/predictions/fertilizer` | Nutrient gap review |
| `POST /api/predictions/disease` | Image screening demo |
| `GET /api/weather` | Weather adapter with fallback |
| `GET /api/alerts` | Authorized open alerts |
| `POST /api/assistant/chat` | Local relevance-gated assistant with agricultural and general knowledge-base context |

Assistant requests keep the application response language separate from the
voice-conversation language. `response_language` controls the text answer
(`en` or `ta`). Optional `voice_language` controls the spoken answer and may
be different; when it differs, the response includes `voice_answer` and
`voice_language`. The assistant requires no external API key. If the local
knowledge base has no relevant source, the endpoint returns a clear fallback in
the selected application language rather than unrelated agriculture content.

```json
{
  "question": "When should I irrigate my field?",
  "response_language": "en",
  "voice_language": "ta"
}
```

Example sensor payload:

```json
{"soil_moisture":35,"temperature":31,"humidity":60,"rainfall":0,"nitrogen":80,"phosphorus":40,"potassium":40}
```
