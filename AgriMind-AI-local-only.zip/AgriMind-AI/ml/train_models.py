"""Create transparent baseline scikit-learn artifacts from included synthetic samples.
Replace data/sample_agronomy.csv with licensed local data before production use.
"""
from pathlib import Path
import joblib, pandas as pd
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, mean_absolute_error

ROOT=Path(__file__).resolve().parent; DATA=ROOT/'data'/'sample_agronomy.csv'; OUT=ROOT/'artifacts'; OUT.mkdir(exist_ok=True)
df=pd.read_csv(DATA); X=df[['nitrogen','phosphorus','potassium','temperature','humidity','ph','rainfall','soil_moisture']]
for target,name,kind in [('crop','crop_classifier','class'),('yield_tonnes_per_acre','yield_regressor','reg')]:
    x_train,x_test,y_train,y_test=train_test_split(X,df[target],test_size=.25,random_state=42)
    model=RandomForestClassifier(n_estimators=200,random_state=42) if kind=='class' else RandomForestRegressor(n_estimators=200,random_state=42)
    model.fit(x_train,y_train); pred=model.predict(x_test); score=accuracy_score(y_test,pred) if kind=='class' else mean_absolute_error(y_test,pred)
    joblib.dump({'model':model,'features':list(X.columns),'metric':float(score),'metric_name':'accuracy' if kind=='class' else 'mae'},OUT/f'{name}.joblib')
    print(f'{name}: {score:.3f}')
print(f'Artifacts saved in {OUT}')
