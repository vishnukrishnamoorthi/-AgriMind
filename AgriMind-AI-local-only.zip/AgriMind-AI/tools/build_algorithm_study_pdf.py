from pathlib import Path
from textwrap import wrap


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "deliverables" / "AgriMind_AI_Algorithm_Study_Guide.pdf"
PAGE_WIDTH = 595
PAGE_HEIGHT = 842
LEFT = 54
TOP = 790
BOTTOM = 58
LINE_HEIGHT = 14


CONTENT = [
    ("title", "AgriMind AI"),
    ("subtitle", "Algorithm and Model Study Guide"),
    ("body", "A code-grounded explanation of the smart agriculture project for study, viva preparation, and technical presentation."),
    ("heading", "1. Project Overview"),
    ("body", "AgriMind AI is a local-first agricultural decision-support application. The browser frontend sends validated requests to a FastAPI backend. The backend stores farm and sensor data, applies prediction or retrieval logic, and returns an explanation-oriented result."),
    ("body", "The project combines deterministic algorithms, optional machine-learning models, image classification, retrieval, sensor rules, authentication, and weather integration. The default demo is designed to run without paid cloud services."),
    ("heading", "2. Important Runtime Fact"),
    ("body", "The live API does not currently use the trained Random Forest artifacts for crop or yield inference. The active crop and yield endpoints call transparent formula-based functions in backend/app/services.py. The Random Forest script is an optional training path for future integration."),
    ("body", "The disease classifier is also optional. If TensorFlow or a trained model is unavailable, the API validates the uploaded image and returns a clearly labelled demo response instead of inventing a diagnosis."),
    ("heading", "3. End-to-End Flow"),
    ("bullet", "1. The user enters soil, weather, crop, or image information in the frontend."),
    ("bullet", "2. The frontend sends the request to a FastAPI endpoint."),
    ("bullet", "3. Pydantic schemas validate important ranges and required fields."),
    ("bullet", "4. The service selects a rule algorithm, trained model, retrieval method, or alert rule."),
    ("bullet", "5. The result is logged in the prediction log when applicable."),
    ("bullet", "6. The frontend displays the result with confidence, drivers, sources, or safety guidance."),
    ("heading", "4. Crop Recommendation Algorithm"),
    ("body", "The crop recommendation function compares the supplied field conditions with an ideal profile for Rice, Maize, Cotton, Chickpea, and Banana."),
    ("body", "Features used: nitrogen, phosphorus, potassium, temperature, rainfall, and soil pH. Humidity is accepted by the API schema but is not used by this active rule function."),
    ("body", "For every crop, the implementation calculates a normalized absolute distance:"),
    ("formula", "d = sum(abs(observed_i - profile_i) / scale_i)"),
    ("body", "The distance is converted into a score:"),
    ("formula", "score = 1 / (1 + d)"),
    ("body", "Scores are normalized into percentages, sorted from highest to lowest, and returned as the recommendation plus two alternatives. This is an explainable nearest-profile method, not a trained classifier."),
    ("heading", "5. Yield Estimation Algorithm"),
    ("body", "The active yield estimator first selects a base yield from the crop name. It then applies nutrition, water, and temperature factors."),
    ("formula", "yield_per_acre = base_yield * nutrition_factor * water_factor * heat_factor"),
    ("body", "The nutrition factor increases with nitrogen and is capped. The water factor uses rainfall and soil moisture and is capped. The heat factor decreases as temperature moves away from the reference temperature of 27 degrees C."),
    ("formula", "total_yield = yield_per_acre * area_acres"),
    ("body", "The result includes a fixed plus-or-minus 25 percent confidence band and a list of the factors used. This makes the calculation easy to explain, but the uncertainty is not learned from validation data."),
    ("heading", "6. Irrigation Planning Algorithm"),
    ("body", "Each supported crop has a target soil moisture. The algorithm compares current moisture with the target and calculates a deficit."),
    ("formula", "deficit = max(0, target_moisture - current_moisture)"),
    ("body", "A heat and humidity factor adjusts demand. Forecast rain receives partial credit, then the remaining deficit is converted into litres using field area and a demo conversion factor."),
    ("formula", "litres = max(0, deficit - rain_credit) * 45 * area * heat_factor"),
    ("body", "Urgency is high for a large deficit with little forecast rain, medium for a moderate deficit, and low otherwise. The output also recommends checking root-zone moisture and irrigation flow."),
    ("heading", "7. Fertilizer Review"),
    ("body", "The nutrient review is a threshold algorithm. It calculates gaps against demo reference values for nitrogen, phosphorus, and potassium."),
    ("formula", "gap = max(0, target - observed)"),
    ("body", "A nutrient becomes a priority when its gap is greater than 10. The function intentionally does not produce a fertilizer product dose. The response directs the user to soil testing and local agricultural guidance."),
    ("heading", "8. Random Forest Training Models"),
    ("body", "The training script is ml/train_models.py. It reads ml/data/sample_agronomy.csv and trains two scikit-learn models."),
    ("bullet", "Crop classifier: RandomForestClassifier predicts the crop class."),
    ("bullet", "Yield regressor: RandomForestRegressor predicts tonnes per acre."),
    ("bullet", "Both models use eight features: N, P, K, temperature, humidity, pH, rainfall, and soil moisture."),
    ("bullet", "Each model uses 200 decision trees and random_state=42."),
    ("bullet", "The data is split into 75 percent training and 25 percent testing data."),
    ("bullet", "Classification is measured with accuracy; regression is measured with mean absolute error."),
    ("body", "A random forest is an ensemble of decision trees. Each tree learns branching rules from a sample of data. Classification combines tree votes, while regression averages tree predictions."),
    ("body", "The artifacts are saved with Joblib, including the model, feature names, metric, and metric name. The dataset has only 15 synthetic rows, so its evaluation is not suitable for production claims."),
    ("heading", "9. EfficientNet Disease Model"),
    ("body", "computer_vision/train.py provides an optional transfer-learning pipeline. It loads an ImageNet-pretrained EfficientNetB0 without its original classification head."),
    ("bullet", "Images are loaded from folders representing class names."),
    ("bullet", "The dataset is split into training and validation subsets."),
    ("bullet", "Images are resized to 224 by 224 pixels."),
    ("bullet", "The EfficientNet backbone is frozen."),
    ("bullet", "Global average pooling, dropout, and a softmax output layer are added."),
    ("bullet", "The model is trained with Adam and sparse categorical cross-entropy."),
    ("body", "During inference, the uploaded image is converted to RGB, resized, preprocessed with EfficientNet preprocessing, and passed to the model. The class with the largest probability is returned."),
    ("formula", "predicted_class = argmax(model(image_probabilities))"),
    ("body", "The system treats this as screening only. It does not prescribe pesticides and asks for agronomist confirmation."),
    ("heading", "10. Local RAG Assistant"),
    ("body", "The assistant uses TF-IDF retrieval over Markdown documents in genai/knowledge_base. It is retrieval-based and does not currently generate text with an LLM."),
    ("bullet", "Load the local Markdown documents."),
    ("bullet", "Convert each document and the user question into TF-IDF vectors."),
    ("bullet", "Compare the question vector with every document vector."),
    ("bullet", "Select the document with the highest similarity."),
    ("bullet", "Return an excerpt and the document name as the source."),
    ("formula", "similarity(question, document) = tfidf(question) dot tfidf(document)"),
    ("body", "The approach is fast, offline, and auditable. Its limitation is that it returns the first excerpt from the selected document rather than composing a context-aware answer."),
    ("heading", "11. Sensor Alert Algorithm"),
    ("body", "When a sensor reading is ingested, the API stores it and evaluates two threshold rules."),
    ("bullet", "Soil moisture below 28 creates a high-severity low-moisture alert."),
    ("bullet", "Temperature above 38 creates a medium-severity heat-stress alert."),
    ("body", "This is event-triggered rule processing. It is not a predictive anomaly-detection model."),
    ("heading", "12. Viva Questions and Answers"),
    ("qa", "Q: Is the current crop recommendation a machine-learning model? A: No. The active API uses a transparent profile-distance rule model. A Random Forest classifier is available as a separate training script."),
    ("qa", "Q: Why use Random Forest? A: It handles nonlinear relationships, works with mixed agricultural features, and is easier to explain than many deep models. However, it needs a larger and representative dataset."),
    ("qa", "Q: What does EfficientNet contribute? A: It provides pretrained visual feature extraction for leaf images, reducing the amount of data and training needed compared with training a CNN from scratch."),
    ("qa", "Q: Is the assistant generative AI? A: Not in the default implementation. It uses TF-IDF to retrieve a relevant local document and returns an excerpt. Bedrock is a documented future integration."),
    ("qa", "Q: Why are safety disclaimers important? A: Agricultural recommendations depend on crop stage, soil tests, local weather, regulations, and field inspection. The project presents outputs as decision support rather than automatic treatment decisions."),
    ("heading", "13. Key Limitations"),
    ("bullet", "The agronomy sample data is synthetic and very small."),
    ("bullet", "The active formula estimators are not calibrated against field outcomes."),
    ("bullet", "The trained Random Forest artifacts are not connected to the live prediction endpoints."),
    ("bullet", "The disease model requires a properly licensed and representative image dataset."),
    ("bullet", "TF-IDF retrieval does not understand meaning as deeply as a reviewed language model or embedding search system."),
    ("bullet", "Sensor alerts use fixed thresholds and do not detect complex trends or faulty sensors."),
    ("heading", "14. Files to Study"),
    ("body", "Start with backend/app/services.py for the active algorithms. Then read backend/app/main.py for API routing, backend/app/schemas.py for input validation, ml/train_models.py for Random Forest training, computer_vision/train.py for EfficientNet training, and genai/knowledge_base for retrieval sources."),
    ("body", "The project documentation in README.md, docs/REPORT.md, and docs/ARCHITECTURE.md explains the intended deployment and safety boundaries."),
]


def pdf_escape(value):
    return value.replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)")


def add_text(commands, text, x, y, size, font="F1"):
    commands.append(f"BT /{font} {size} Tf {x} {y} Td ({pdf_escape(text)}) Tj ET")


def build_pages():
    pages = []
    current = []
    y = TOP

    def flush():
        nonlocal current, y
        if current:
            pages.append(current)
        current = []
        y = TOP

    for kind, text in CONTENT:
        needed = 42 if kind == "title" else 30 if kind in {"heading", "subtitle"} else LINE_HEIGHT
        if y - needed < BOTTOM:
            flush()

        if kind == "title":
            add_text(current, text, LEFT, y, 25, "F2")
            y -= 38
        elif kind == "subtitle":
            add_text(current, text, LEFT, y, 16, "F2")
            y -= 28
        elif kind == "heading":
            y -= 8
            add_text(current, text, LEFT, y, 14, "F2")
            y -= 22
        else:
            prefix = "- " if kind == "bullet" else ""
            font = "F3" if kind in {"formula", "qa"} else "F1"
            width = 86 if kind != "bullet" else 82
            for line in wrap(prefix + text, width=width, break_long_words=False):
                if y - LINE_HEIGHT < BOTTOM:
                    flush()
                add_text(current, line, LEFT, y, 10, font)
                y -= LINE_HEIGHT
            y -= 4
    flush()
    return pages


def make_pdf():
    pages = build_pages()
    objects = []

    def obj(value):
        objects.append(value)
        return len(objects)

    font_regular = obj("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>")
    font_bold = obj("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >>")
    font_mono = obj("<< /Type /Font /Subtype /Type1 /BaseFont /Courier >>")
    page_ids = []
    content_ids = []
    for page_commands in pages:
        page_commands.append(f"BT /F1 8 Tf {LEFT} 35 Td (AgriMind AI Algorithm Study Guide) Tj ET")
        stream = "\n".join(page_commands).encode("latin-1", "replace")
        content_ids.append(obj(f"<< /Length {len(stream)} >>\nstream\n{stream.decode('latin-1')}\nendstream"))
        page_ids.append(obj(""))

    pages_id = obj("")
    for index, page_id in enumerate(page_ids):
        objects[page_id - 1] = (
            f"<< /Type /Page /Parent {pages_id} 0 R /MediaBox [0 0 {PAGE_WIDTH} {PAGE_HEIGHT}] "
            f"/Resources << /Font << /F1 {font_regular} 0 R /F2 {font_bold} 0 R /F3 {font_mono} 0 R >> >> "
            f"/Contents {content_ids[index]} 0 R >>"
        )
    objects[pages_id - 1] = f"<< /Type /Pages /Kids [{' '.join(f'{x} 0 R' for x in page_ids)}] /Count {len(page_ids)} >>"
    catalog_id = obj(f"<< /Type /Catalog /Pages {pages_id} 0 R >>")

    output = bytearray(b"%PDF-1.4\n%\xe2\xe3\xcf\xd3\n")
    offsets = [0]
    for number, value in enumerate(objects, 1):
        offsets.append(len(output))
        output.extend(f"{number} 0 obj\n{value}\nendobj\n".encode("latin-1", "replace"))
    xref = len(output)
    output.extend(f"xref\n0 {len(objects) + 1}\n0000000000 65535 f \n".encode())
    for offset in offsets[1:]:
        output.extend(f"{offset:010d} 00000 n \n".encode())
    output.extend(f"trailer\n<< /Size {len(objects) + 1} /Root {catalog_id} 0 R >>\nstartxref\n{xref}\n%%EOF\n".encode())
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_bytes(output)
    print(f"Created {OUT} ({len(pages)} pages)")


if __name__ == "__main__":
    make_pdf()