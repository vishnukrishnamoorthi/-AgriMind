import fs from 'node:fs/promises';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
const workspaceDir=path.resolve('.');const skillDir=process.env.SKILL_DIR;const runtimePython=process.env.RUNTIME_PYTHON;
const {finalizePresentation}=await import(pathToFileURL(path.join(skillDir,'container_tools/artifact_tool_utils.mjs')).href);
const staging=path.join(workspaceDir,'.ppt-finalizer');const finalPath=path.join(workspaceDir,'deliverables','AgriMind_AI_Project_Presentation.pptx');await fs.mkdir(staging,{recursive:true});await fs.mkdir(path.dirname(finalPath),{recursive:true});
const result=await finalizePresentation({workspaceDir,candidatePath:path.join(workspaceDir,'.ppt-build','AgriMind_AI_Project_Presentation_draft.pptx'),finalPath,pythonExecutable:runtimePython,integrityValidatorPath:path.join(skillDir,'container_tools','inspect_presentation_package_integrity.py'),layoutValidatorPath:path.join(skillDir,'container_tools','inspect_presentation_layout_geometry.py'),layoutArgs:['--expected-slide-size-emu','12192000,6858000','--validate-heading-fit'],explicitTotalSlideCount:8,requiredNativeTableOwnerSlides:[],verifyArtifactToolImport:true,receiptPath:path.join(staging,'validation.json')});console.log(JSON.stringify(result));
