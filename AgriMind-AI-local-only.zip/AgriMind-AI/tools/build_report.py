from pathlib import Path
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

OUT=Path(__file__).resolve().parents[1]/'deliverables'/'AgriMind_AI_Project_Report.docx'
def shade(cell, color):
    p=cell._tc.get_or_add_tcPr(); s=OxmlElement('w:shd'); s.set(qn('w:fill'),color); p.append(s)
def margin(cell):
    tc=cell._tc; tcPr=tc.get_or_add_tcPr(); mar=OxmlElement('w:tcMar')
    for e in ('top','start','bottom','end'):
        n=OxmlElement(f'w:{e}'); n.set(qn('w:w'),'120'); n.set(qn('w:type'),'dxa'); mar.append(n)
    tcPr.append(mar)
def add_table(doc, headers, rows, widths=None):
    t=doc.add_table(rows=1, cols=len(headers));t.alignment=WD_TABLE_ALIGNMENT.CENTER;t.style='Table Grid'
    for i,h in enumerate(headers):
        c=t.rows[0].cells[i];c.text=h;shade(c,'173128');margin(c)
        for r in c.paragraphs[0].runs:r.font.color.rgb=RGBColor(255,255,255);r.font.bold=True
    for ri,row in enumerate(rows):
        cells=t.add_row().cells
        for i,v in enumerate(row):
            cells[i].text=str(v);margin(cells[i]);cells[i].vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
            if ri%2==1:shade(cells[i],'F2F7F3')
    if widths:
        for row in t.rows:
            for i,w in enumerate(widths):row.cells[i].width=Inches(w)
    doc.add_paragraph()
def title(doc,text):
    p=doc.add_paragraph(style='Title');p.alignment=WD_ALIGN_PARAGRAPH.CENTER;r=p.add_run(text);r.font.color.rgb=RGBColor(0,0,0)
def section(doc,text):
    p=doc.add_heading(text,level=1)
    for r in p.runs:r.font.color.rgb=RGBColor(0,0,0)
def bullet(doc,text):doc.add_paragraph(text,style='List Bullet')

doc=Document(); sec=doc.sections[0];sec.top_margin=Inches(.7);sec.bottom_margin=Inches(.7);sec.left_margin=Inches(.8);sec.right_margin=Inches(.8)
styles=doc.styles;styles['Normal'].font.name='Aptos';styles['Normal'].font.size=Pt(10.5);styles['Normal'].paragraph_format.space_after=Pt(7)
title(doc,'AgriMind AI Project Report')
p=doc.add_paragraph();p.alignment=WD_ALIGN_PARAGRAPH.CENTER;p.add_run('AI Powered Smart Agriculture Decision Support Platform').bold=True
p=doc.add_paragraph();p.alignment=WD_ALIGN_PARAGRAPH.CENTER;p.add_run('Local first full stack project with optional AWS deployment').italic=True
doc.add_paragraph('This report documents a runnable end to end application for farm management, IoT sensor simulation, analytics, predictive decision support, image screening, and a grounded farming assistant. The project deliberately labels simulation and API dependent features so it can be demonstrated locally without a paid cloud account.')
section(doc,'Project Summary')
doc.add_paragraph('AgriMind AI consolidates common farm signals into a role protected dashboard. Farmers can manage farms, ingest readings, view alerts, request crop and irrigation guidance, review nutrient gaps, estimate yield, screen a leaf image, and ask a cited local assistant. The system supports a course demonstration while documenting a safe migration path to AWS.')
add_table(doc,['Component','Local demonstration','Production direction'],[
['Application','FastAPI and responsive browser dashboard','API Gateway, Lambda or container service'],
['Data','SQLite with seeded demo farm','DynamoDB, Aurora, or RDS with backups'],
['IoT','REST simulator and dashboard action','MQTT over TLS through AWS IoT Core'],
['ML','Rule estimators and optional scikit learn scripts','Versioned, evaluated regional model artifacts'],
['GenAI','TF IDF retrieval over approved Markdown','Bedrock with policy controls and monitoring'],
['Storage','Local upload workflow','Private encrypted S3 bucket']], [1.2,2.35,2.35])
section(doc,'Objectives')
for x in ['Provide authenticated multi role farm management.','Ingest validated soil and climate telemetry and generate threshold alerts.','Offer crop recommendation, yield estimation, irrigation planning, and nutrient gap review.','Demonstrate safe crop disease image screening without pesticide prescriptions.','Provide sourced answers through a local retrieval augmented assistant.','Document Docker and AWS deployment paths.']:bullet(doc,x)
section(doc,'Architecture')
doc.add_paragraph('The browser dashboard communicates with a FastAPI API. JWT authentication and ownership checks protect protected records. SQLAlchemy stores local demo data in SQLite. Prediction and RAG services run inside the application. The weather adapter uses Open Meteo when available and returns a labelled local fallback when unavailable. An IoT simulator posts the same schema used by connected devices.')
add_table(doc,['Layer','Responsibilities'],[['Presentation','Responsive dashboard for farms, predictions, alerts, and assistant'],['API','Validation, authentication, role checks, audit logging, OpenAPI'],['Domain','Agronomy inspired estimators, alert rules, weather adapter, RAG'],['Data','Users, farms, readings, alerts, prediction logs'],['Cloud option','SAM baseline for API Gateway, Lambda, S3, DynamoDB, and Bedrock permissions']], [1.5,4.4])
section(doc,'Key Features and Safety')
doc.add_paragraph('All estimates are decision support only. The included data is synthetic. Model output must be verified with local soil tests, crop stage, water availability, local regulations, and a qualified agronomist. The disease screen is explicitly marked as a demo when a trained image model is absent and it never recommends pesticides.')
section(doc,'Validation and Demonstration')
doc.add_paragraph('The repository contains API tests for health, sign in, farm access, crop recommendation, and sensor ingestion. A syntax compilation check passed in the packaging environment. The package manager could not create usable isolated dependencies in the local verification environment because of operating system permissions, so runtime tests must be executed in a standard Python 3.11 environment using the documented commands.')
section(doc,'AWS Deployment')
doc.add_paragraph('The aws directory supplies an AWS SAM baseline with encrypted S3, API Gateway, Lambda, DynamoDB, and optional Bedrock permissions. Before deployment, remove demo accounts, replace SQLite, narrow IAM permissions, store secrets safely, authenticate devices, restrict CORS, enable monitoring, and complete privacy, security, model risk, and agricultural safety reviews.')
section(doc,'Conclusion')
doc.add_paragraph('AgriMind AI provides a coherent portfolio implementation rather than a disconnected set of examples. It demonstrates local functionality first, clearly describes simulations and limitations, and leaves structured extension points for IoT, trained models, GenAI, and AWS production services.')
OUT.parent.mkdir(parents=True,exist_ok=True);doc.save(OUT);print(OUT)
