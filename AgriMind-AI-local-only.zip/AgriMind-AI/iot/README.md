# IoT integration

For the local demo, use the dashboard simulation button or `simulator.py`. A production sensor adapter should validate device identity, enforce a schema, sign messages, buffer offline readings, and use MQTT over TLS. Amazon IoT Core can route a verified topic to Lambda/API ingestion; the provided app endpoint remains the normalized ingestion boundary.
