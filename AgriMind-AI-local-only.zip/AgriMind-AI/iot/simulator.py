"""Send simulated readings to a running local AgriMind API."""
import argparse, random, time, requests
p=argparse.ArgumentParser();p.add_argument('--farm-id',type=int,default=1);p.add_argument('--token',required=True);p.add_argument('--url',default='http://127.0.0.1:8000');p.add_argument('--seconds',type=int,default=30);args=p.parse_args()
headers={'Authorization':f'Bearer {args.token}'}
while True:
    data={'soil_moisture':round(random.uniform(22,70),1),'temperature':round(random.uniform(24,40),1),'humidity':round(random.uniform(35,90),1),'rainfall':round(random.uniform(0,6),1),'nitrogen':round(random.uniform(60,110),1),'phosphorus':round(random.uniform(30,55),1),'potassium':round(random.uniform(30,60),1)}
    r=requests.post(f'{args.url}/api/farms/{args.farm_id}/sensors',json=data,headers=headers,timeout=10);print(r.status_code,data);time.sleep(args.seconds)
