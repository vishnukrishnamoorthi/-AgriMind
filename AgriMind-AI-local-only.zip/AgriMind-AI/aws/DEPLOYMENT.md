# AWS deployment guide

## Architecture choice

Use the local Docker deployment for course demonstrations. The supplied SAM template is a serverless baseline: API Gateway routes requests to Lambda, S3 holds approved image uploads, DynamoDB is available for a production repository adapter, and Bedrock access is disabled by default. The current local SQLAlchemy database uses SQLite and must be replaced by DynamoDB, Aurora Serverless, or RDS before a multi-user production deployment.

## Prerequisites

Install AWS CLI and SAM CLI, authenticate to the intended AWS account, select a region where your chosen Bedrock model is enabled, and review service pricing. Do not deploy with the seeded passwords or default secret.

## Deploy

```bash
cd aws
sam build --template-file template.yaml
sam deploy --guided
```

Set a strong `SECRET_KEY` in Lambda configuration or Secrets Manager. Set `BEDROCK_ENABLED=false` until an organization-approved GenAI policy and model access are in place. The template deliberately uses encrypted S3 and no public bucket access.

## Production hardening checklist

- Replace SQLite with an HA managed data store and run migrations.
- Add Cognito or a managed identity provider. Remove demo accounts.
- Put CloudFront and WAF in front of the UI and restrict CORS.
- Use Secrets Manager and least-privilege IAM scoped to the selected model and bucket.
- Add CloudWatch alarms, audit logs, backups, retention settings, and incident runbooks.
- Validate sensor certificates and use AWS IoT Core MQTT over TLS.
- Conduct privacy, security, model-risk, and agricultural safety reviews.
