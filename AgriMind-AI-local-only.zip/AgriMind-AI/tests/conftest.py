import os
os.environ['DATABASE_URL'] = 'sqlite:///./test_agrimind.db'
from fastapi.testclient import TestClient
from backend.app.main import app
import pytest

@pytest.fixture
def client():
    with TestClient(app) as c:
        yield c

@pytest.fixture
def farmer_token(client):
    r = client.post('/api/auth/login', json={'email':'farmer@agrimind.local','password':'Farmer@123'})
    return r.json()['token']
