def auth(token): return {'Authorization': f'Bearer {token}'}

def test_health(client):
    assert client.get('/api/health').status_code == 200

def test_weather_accepts_coordinates(client, farmer_token):
    response = client.get('/api/weather?latitude=11.0168&longitude=76.9558', headers=auth(farmer_token))
    assert response.status_code == 200
    assert response.json()['location'] in {'Current location', 'Coimbatore, India'}

def test_weather_rejects_partial_coordinates(client, farmer_token):
    response = client.get('/api/weather?latitude=11.0168', headers=auth(farmer_token))
    assert response.status_code == 400

def test_login_and_farms(client, farmer_token):
    r = client.get('/api/farms', headers=auth(farmer_token))
    assert r.status_code == 200 and len(r.json()) >= 1

def test_crop_prediction(client, farmer_token):
    body = {'nitrogen':90,'phosphorus':42,'potassium':43,'temperature':27,'humidity':80,'ph':6.5,'rainfall':190}
    r = client.post('/api/predictions/crop', json=body, headers=auth(farmer_token))
    assert r.status_code == 200 and 'recommended_crop' in r.json()

def test_sensor_ingestion(client, farmer_token):
    body = {'soil_moisture':20,'temperature':35,'humidity':60,'rainfall':0,'nitrogen':80,'phosphorus':40,'potassium':40}
    assert client.post('/api/farms/1/sensors', json=body, headers=auth(farmer_token)).status_code == 200

def test_simulate_sensor_returns_reading(client, farmer_token):
    response = client.post('/api/farms/1/simulate-sensor', headers=auth(farmer_token))
    assert response.status_code == 200
    assert response.json()['message'] == 'Sensor reading stored and alert rules checked'

def test_live_crop_analysis_uses_latest_sensor_reading(client, farmer_token):
    response = client.get('/api/analytics/live-crop', headers=auth(farmer_token))
    assert response.status_code == 200
    payload = response.json()
    assert payload['available'] is True
    assert payload['status'] in {'Healthy', 'Watch', 'Action needed'}
    assert 'recommendation' in payload

def test_vegetable_market_terms_are_available(client, farmer_token):
    response = client.get('/api/market/vegetables', headers=auth(farmer_token))
    assert response.status_code == 200
    payload = response.json()
    assert len(payload['vegetables']) >= 3
    assert any('Payment' in title for title, _ in payload['terms'])
    assert 'Indicative' in payload['disclaimer']
    assert 'prices' in payload
    assert 'available' in payload['prices']

def test_disease_upload_validates_image_and_returns_demo_result(client, farmer_token):
    png = b'\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR\x00\x00\x00\x01\x00\x00\x00\x01\x08\x02\x00\x00\x00\x90wS\xde\x00\x00\x00\x0cIDAT\x08\xd7c\xf8\xcf\xc0\xf0\x1f\x00\x05\x00\x01\xff\x89\x99=\x1d\x00\x00\x00\x00IEND\xaeB`\x82'
    response = client.post('/api/predictions/disease', files={'image': ('leaf.png', png, 'image/png')}, headers=auth(farmer_token))
    assert response.status_code == 200
    assert response.json()['mode'] == 'demo upload validation'

def test_disease_upload_rejects_non_image(client, farmer_token):
    response = client.post('/api/predictions/disease', files={'image': ('leaf.txt', b'not an image', 'text/plain')}, headers=auth(farmer_token))
    assert response.status_code == 400

def test_assistant_keeps_application_and_voice_languages_separate(client, farmer_token, monkeypatch):
    response = client.post(
        '/api/assistant/chat',
        json={
            'question': 'எனது வயலுக்கு எப்போது நீர்ப்பாசனம் செய்ய வேண்டும்?',
            'response_language': 'en',
            'voice_language': 'ta',
        },
        headers=auth(farmer_token),
    )
    assert response.status_code == 200
    payload = response.json()
    assert 'Irrigation guidance' in payload['answer']
    assert 'நீர்ப்பாசனம்' in payload['voice_answer']
    assert payload['voice_language'] == 'ta'

def test_assistant_returns_tamil_text_without_changing_voice_language(client, farmer_token, monkeypatch):
    response = client.post(
        '/api/assistant/chat',
        json={
            'question': 'When should I irrigate my field?',
            'response_language': 'ta',
            'voice_language': 'en',
        },
        headers=auth(farmer_token),
    )
    assert response.status_code == 200
    payload = response.json()
    assert 'நீர்ப்பாசனம்' in payload['answer']
    assert 'Irrigation guidance' in payload['voice_answer']
    assert payload['voice_language'] == 'en'

def test_assistant_returns_local_fallback_for_unrelated_question(client, farmer_token):
    response = client.post(
        '/api/assistant/chat',
        json={'question': 'What is the latest cyclone name today?', 'response_language': 'en'},
        headers=auth(farmer_token),
    )
    assert response.status_code == 200
    assert 'local knowledge base does not contain' in response.json()['answer']

def test_assistant_answers_local_general_topics(client, farmer_token):
    response = client.post(
        '/api/assistant/chat',
        json={'question': 'What documents should I check for a government application?', 'response_language': 'en'},
        headers=auth(farmer_token),
    )
    assert response.status_code == 200
    assert 'Government application guidance' in response.json()['answer']
