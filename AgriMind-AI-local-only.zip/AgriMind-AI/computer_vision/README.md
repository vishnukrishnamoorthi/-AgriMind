# Crop disease model

The application ships in clearly labelled demo mode to stay runnable without a large model. This folder provides an EfficientNetB0 transfer-learning training script for a licensed, curated dataset. Keep classes, class balance, geographic applicability, evaluation splits, and model cards under version control. Add a human-review workflow before showing any diagnosis to farmers.
