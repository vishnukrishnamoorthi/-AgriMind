"""Transfer-learning trainer. Expected layout: data/Class Name/image.jpg."""
import argparse
from pathlib import Path
import tensorflow as tf
from tensorflow.keras import layers

p=argparse.ArgumentParser();p.add_argument('--data',required=True);p.add_argument('--epochs',type=int,default=8);p.add_argument('--output',default='ml/artifacts/disease_model.keras');args=p.parse_args()
data=Path(args.data); train=tf.keras.utils.image_dataset_from_directory(data,validation_split=.2,subset='training',seed=42,image_size=(224,224),batch_size=16); val=tf.keras.utils.image_dataset_from_directory(data,validation_split=.2,subset='validation',seed=42,image_size=(224,224),batch_size=16)
classes=train.class_names; auto=tf.data.AUTOTUNE;train=train.prefetch(auto);val=val.prefetch(auto)
base=tf.keras.applications.EfficientNetB0(include_top=False,weights='imagenet',input_shape=(224,224,3));base.trainable=False
model=tf.keras.Sequential([base,layers.GlobalAveragePooling2D(),layers.Dropout(.25),layers.Dense(len(classes),activation='softmax')]);model.compile(optimizer='adam',loss='sparse_categorical_crossentropy',metrics=['accuracy']);model.fit(train,validation_data=val,epochs=args.epochs)
Path(args.output).parent.mkdir(parents=True,exist_ok=True);model.save(args.output);Path(args.output+'.labels.txt').write_text('\n'.join(classes));print('Saved',args.output)
