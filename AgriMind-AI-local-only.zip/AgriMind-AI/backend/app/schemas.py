from datetime import datetime
from pydantic import BaseModel, Field

class RegisterIn(BaseModel): name: str; email: str; password: str = Field(min_length=8); role: str = "farmer"
class LoginIn(BaseModel): email: str; password: str
class FarmIn(BaseModel): name: str; location: str = "Coimbatore, India"; area_acres: float = Field(gt=0); crop: str = "Rice"
class SensorIn(BaseModel):
    soil_moisture: float = Field(ge=0, le=100); temperature: float = Field(ge=-20, le=70)
    humidity: float = Field(ge=0, le=100); rainfall: float = Field(ge=0, default=0)
    nitrogen: float = Field(ge=0, le=300, default=80); phosphorus: float = Field(ge=0, le=200, default=40); potassium: float = Field(ge=0, le=200, default=40)
class CropInput(BaseModel): nitrogen: float; phosphorus: float; potassium: float; temperature: float; humidity: float; ph: float = Field(ge=0, le=14); rainfall: float
class YieldInput(BaseModel): crop: str; area_acres: float = Field(gt=0); nitrogen: float; rainfall: float; temperature: float; soil_moisture: float
class IrrigationInput(BaseModel): crop: str; soil_moisture: float; temperature: float; humidity: float; rainfall_forecast: float = 0; area_acres: float = 1
class ChatIn(BaseModel):
    question: str = Field(min_length=3, max_length=800)
    response_language: str = Field(default="en", pattern="^(en|ta)$")
    voice_language: str | None = Field(default=None, pattern="^(en|ta)$")
    location: str | None = Field(default=None, max_length=160)
    latitude: float | None = Field(default=None, ge=-90, le=90)
    longitude: float | None = Field(default=None, ge=-180, le=180)
class UserOut(BaseModel): id: int; name: str; email: str; role: str
class FarmOut(BaseModel): id: int; name: str; location: str; area_acres: float; crop: str
class SensorOut(SensorIn): id: int; farm_id: int; captured_at: datetime
