"""AWS Lambda entrypoint. For production replace SQLite with DynamoDB/RDS adapter."""
from mangum import Mangum
from .main import app
handler = Mangum(app, lifespan="off")
