"""Prediction, weather, alert, and local assistant services."""
import io, json, math, random, re
from collections import defaultdict, deque
from datetime import datetime
from functools import lru_cache
from pathlib import Path
import httpx
from sqlalchemy.orm import Session
from .config import ROOT, settings
from .models import Alert, SensorReading

_assistant_history: dict[int, deque[str]] = defaultdict(lambda: deque(maxlen=6))

class AssistantServiceError(Exception):
    def __init__(self, status_code: int, message: str):
        super().__init__(message)
        self.status_code = status_code
        self.message = message

CROP_PROFILES = {
    "Rice": {"n": 90, "p": 42, "k": 43, "temp": 27, "rain": 190},
    "Maize": {"n": 110, "p": 50, "k": 45, "temp": 24, "rain": 95},
    "Cotton": {"n": 85, "p": 35, "k": 40, "temp": 29, "rain": 75},
    "Chickpea": {"n": 25, "p": 55, "k": 45, "temp": 22, "rain": 55},
    "Banana": {"n": 120, "p": 45, "k": 70, "temp": 28, "rain": 140},
}
def crop_recommendation(x: dict) -> dict:
    scores = []
    for crop, p in CROP_PROFILES.items():
        d = abs(x["nitrogen"]-p["n"])/p["n"] + abs(x["phosphorus"]-p["p"])/p["p"] + abs(x["potassium"]-p["k"])/p["k"] + abs(x["temperature"]-p["temp"])/15 + abs(x["rainfall"]-p["rain"])/200 + abs(x["ph"]-6.5)/7
        scores.append((crop, max(0.05, 1/(1+d))))
    scores.sort(key=lambda v: v[1], reverse=True); total = sum(s for _, s in scores)
    ranked = [{"crop": c, "confidence": round(s/total*100, 1)} for c,s in scores]
    return {"recommended_crop": ranked[0]["crop"], "confidence": ranked[0]["confidence"], "alternatives": ranked[1:3], "mode": "local rule model", "disclaimer": "Validate with local crop calendars, soil tests, water availability, and an agronomist."}
def yield_prediction(x: dict) -> dict:
    base = {"rice": 2.7, "maize": 2.3, "cotton": 0.8, "banana": 12.0}.get(x["crop"].lower(), 1.8)
    nutrition = min(1.15, 0.75 + x["nitrogen"]/300); water = min(1.1, 0.65+x["rainfall"]/500+x["soil_moisture"]/250)
    heat = max(.6, 1-abs(x["temperature"]-27)/40); per_acre = round(base*nutrition*water*heat, 2)
    return {"yield_tonnes_per_acre": per_acre, "total_tonnes": round(per_acre*x["area_acres"],2), "confidence_band": "±25%", "drivers": ["synthetic baseline", "nutrient estimate", "water and temperature proxy"], "mode":"local estimator"}
def irrigation_plan(x: dict) -> dict:
    target = {"rice": 65, "banana": 60, "cotton": 48, "maize": 50}.get(x["crop"].lower(), 50)
    deficit = max(0, target - x["soil_moisture"])
    heat_factor = max(0.7, min(1.4, 1+(x["temperature"]-25)/50-(x["humidity"]-55)/200))
    rain_credit = min(deficit, x["rainfall_forecast"]*0.6)
    litres = round(max(0, (deficit-rain_credit)*45*x["area_acres"]*heat_factor))
    urgency = "high" if deficit > 20 and x["rainfall_forecast"] < 4 else "medium" if deficit > 8 else "low"
    return {"irrigation_litres": litres, "urgency": urgency, "target_moisture": target, "suggested_window": "early morning", "note": "Check root-zone moisture and irrigation-system flow before applying water."}
def fertilizer_review(x: dict) -> dict:
    gaps = {"nitrogen": max(0,90-x["nitrogen"]), "phosphorus": max(0,42-x["phosphorus"]), "potassium": max(0,43-x["potassium"])}
    needs = [k for k,v in gaps.items() if v>10]
    return {"nutrient_gaps": gaps, "priority": needs or ["No major gap in demo thresholds"], "guidance": "Use a certified soil test and local extension recommendation to determine product, dose, timing, and legal restrictions. Do not treat this screen as a fertilizer prescription."}
@lru_cache(maxsize=1)
def _load_disease_model():
    try:
        import tensorflow as tf
    except ImportError as exc:
        raise RuntimeError("TensorFlow is not installed. Install computer_vision/requirements.txt and train the disease model.") from exc

    model_path = Path(settings.model_dir)
    if not model_path.is_absolute():
        model_path = ROOT / model_path
    if model_path.is_dir():
        model_path /= "disease_model.keras"
    if not model_path.exists():
        raise RuntimeError(f"Disease model not found at {model_path}. Train computer_vision/train.py first.")

    labels_path = Path(f"{model_path}.labels.txt")
    if not labels_path.exists():
        raise RuntimeError(f"Disease model labels not found at {labels_path}.")
    labels = [label.strip() for label in labels_path.read_text(encoding="utf-8").splitlines() if label.strip()]
    if not labels:
        raise RuntimeError(f"Disease model labels file is empty: {labels_path}.")
    return tf.keras.models.load_model(model_path), labels


def disease_screen(image) -> dict:
    try:
        import numpy as np
        from PIL import Image, UnidentifiedImageError
    except ImportError as exc:
        raise RuntimeError("NumPy and Pillow are required for image screening.") from exc

    if isinstance(image, Image.Image):
        pil_image = image
    else:
        try:
            pil_image = Image.open(io.BytesIO(image))
        except (TypeError, UnidentifiedImageError, OSError) as exc:
            raise ValueError("The uploaded file is not a valid image.") from exc

    try:
        import tensorflow as tf
        model, labels = _load_disease_model()
    except (ImportError, RuntimeError):
        return {
            "label": "Model unavailable: image received",
            "confidence": None,
            "mode": "demo upload validation",
            "next_steps": "Train the EfficientNet model and repeat the screening before making crop-management decisions.",
            "safety": "This upload was validated, but no disease classification was made and no pesticide recommendation is generated.",
            "reference_url": "https://earthsally.com/disease-control/common-plant-diseases.html",
            "reference_note": "Use a common-disease guide only to compare visible symptoms; it is not an automated diagnosis.",
        }

    pixels = np.asarray(pil_image.convert("RGB").resize((224, 224)), dtype=np.float32)
    batch = tf.keras.applications.efficientnet.preprocess_input(pixels)[None, ...]
    probabilities = np.asarray(model.predict(batch, verbose=0)[0], dtype=np.float32)
    index = int(np.argmax(probabilities))
    if index >= len(labels):
        raise RuntimeError("The number of model outputs does not match the labels file.")
    return {
        "label": labels[index],
        "confidence": round(float(probabilities[index]) * 100, 1),
        "mode": "EfficientNet image classifier",
        "next_steps": "Inspect affected plants and confirm the diagnosis with an agronomist.",
        "safety": "No pesticide recommendation is generated.",
    }
async def weather(location: str, latitude: float | None = None, longitude: float | None = None) -> dict:
    if settings.open_meteo_enabled:
        try:
            async with httpx.AsyncClient(timeout=6) as client:
                if latitude is None or longitude is None:
                    geo = (await client.get("https://geocoding-api.open-meteo.com/v1/search", params={"name":location,"count":1})).json().get("results",[])
                    if not geo:
                        raise ValueError("Location was not found")
                    latitude, longitude, location = geo[0]["latitude"], geo[0]["longitude"], geo[0]["name"]
                data = (await client.get("https://api.open-meteo.com/v1/forecast", params={
                    "latitude": latitude, "longitude": longitude,
                    "current": "temperature_2m,relative_humidity_2m,precipitation,weather_code",
                    "daily": "precipitation_sum,temperature_2m_max", "timezone": "auto",
                })).json()
                return {"source": "Open-Meteo", "location": "Current location" if location == "Coimbatore, India" and latitude is not None else location, "current": data.get("current", {}), "daily": data.get("daily", {}), "simulated": False}
        except Exception: pass
    return {"source":"local demo fallback","location":location,"current":{"temperature_2m":29,"relative_humidity_2m":68,"precipitation":0},"daily":{"precipitation_sum":[2,5,0],"temperature_2m_max":[31,32,30]},"simulated":True}
def create_sensor_alerts(db: Session, reading: SensorReading):
    messages=[]
    if reading.soil_moisture < 28: messages.append(("high","Low soil moisture","Root-zone moisture is below the demo threshold. Inspect the field and irrigation lines."))
    if reading.temperature > 38: messages.append(("medium","Heat stress watch","Temperature is above the demo heat threshold. Consider heat-risk field checks."))
    for sev,title,msg in messages:
        db.add(Alert(farm_id=reading.farm_id,severity=sev,title=title,message=msg))

def live_crop_analysis(reading: dict, crop: str) -> dict:
    signals = []
    score = 100
    moisture = reading["soil_moisture"]
    temperature = reading["temperature"]
    humidity = reading["humidity"]
    if moisture < 28:
        score -= 35
        signals.append({"level": "high", "label": "Moisture is low", "detail": "Inspect root-zone moisture and irrigation lines."})
    elif moisture < 40:
        score -= 15
        signals.append({"level": "medium", "label": "Moisture is trending low", "detail": "Recheck the field before the next irrigation window."})
    if temperature > 38:
        score -= 25
        signals.append({"level": "medium", "label": "Heat stress risk", "detail": "Schedule a field check during the cooler part of the day."})
    if humidity > 85:
        score -= 10
        signals.append({"level": "low", "label": "Humidity is high", "detail": "Increase scouting for fungal symptoms."})
    status = "Healthy" if score >= 80 else "Watch" if score >= 55 else "Action needed"
    return {
        "crop": crop, "status": status, "health_score": score,
        "recommendation": "Conditions look stable. Continue routine monitoring." if status == "Healthy" else "Prioritise a field inspection and confirm the next irrigation decision.",
        "signals": signals, "reading": reading,
    }

async def tamilnadu_vegetable_prices() -> dict:
    vegetables = [
        {"name": "Tomato", "unit": "kg", "quality": "Indicative retail range"},
        {"name": "Onion", "unit": "kg", "quality": "Indicative retail range"},
        {"name": "Brinjal", "unit": "kg", "quality": "Indicative retail range"},
    ]
    return {
        "available": False,
        "vegetables": vegetables,
        "prices": [],
        "terms": [
            ("Payment basis", "Confirm whether the buyer price is per kg, crate, bundle, or lot."),
            ("Payment timing", "Record when payment is due and retain a written receipt."),
        ],
        "disclaimer": "Indicative information only. Confirm current prices with local mandi or buyer quotes.",
    }
def local_rag(question: str, response_language: str = "en") -> dict:
    from sklearn.feature_extraction.text import TfidfVectorizer

    docs = [
        (path.stem, path.read_text(encoding="utf-8"))
        for path in sorted((ROOT / "genai" / "knowledge_base").glob("*.md"))
    ]
    if not docs:
        return {"answer": _assistant_fallback(response_language), "sources": [], "mode": "local RAG", "grounded": True}

    aliases = {
        "irrigation": {"irrigation", "irrigate", "watering", "water", "moisture", "rain", "நீர்ப்பாசனம்", "நீர்", "ஈரப்பதம்", "மழை"},
        "agriculture": {"agriculture", "agricultural", "farm", "farmer", "crop", "soil", "fertilizer", "irrigation", "irrigate", "watering", "water", "leaf", "plant", "பண்ணை", "விவசாயம்", "பயிர்", "மண்", "உரம்", "நீர்ப்பாசனம்"},
        "government_forms": {"government", "form", "certificate", "document", "application", "apply", "scheme", "eligibility", "அரசு", "சான்றிதழ்", "விண்ணப்பம்", "ஆவணம்", "திட்டம்"},
        "education": {"education", "school", "college", "scholarship", "student", "course", "கல்வி", "பள்ளி", "கல்லூரி", "உதவித்தொகை", "மாணவர்"},
        "technology": {"computer", "technology", "programming", "python", "software", "internet", "கணினி", "தொழில்நுட்பம்", "நிரலாக்கம்", "மென்பொருள்"},
        "general": {"general", "everyday", "explain", "meaning", "என்ன", "விளக்கம்"},
    }
    normalized = question.lower()
    query_terms = set(re.findall(r"[a-z0-9]+|[\u0B80-\u0BFF]+", normalized))
    vectorizer = TfidfVectorizer(stop_words="english", ngram_range=(1, 2))
    matrix = vectorizer.fit_transform([text for _, text in docs] + [question])
    scores = (matrix[:-1] @ matrix[-1].T).toarray().ravel()
    topic = None
    topic_score = 0
    for candidate, terms in aliases.items():
        score = sum(1 for term in terms if term in query_terms or term in normalized)
        if score > topic_score:
            topic, topic_score = candidate, score
    document_topics = {
        "irrigation": {"irrigation"},
        "soil": {"soil"},
        "disease_screening": {"disease_screening"},
        "government_forms": {"government_forms"},
        "education": {"education"},
        "technology": {"technology"},
    }
    for index, (name, _) in enumerate(docs):
        if topic and name in document_topics.get(topic, set()):
            scores[index] += 0.35
    index = int(scores.argmax())
    score = float(scores[index]) + min(topic_score * 0.08, 0.32)
    if score < 0.16:
        return {"answer": _assistant_fallback(response_language), "sources": [], "mode": "local RAG · no relevant source", "grounded": True}

    name = docs[index][0]
    answer = _curated_local_answer(name, response_language)
    if answer is None:
        excerpt = re.sub(r"^#+\s*", "", docs[index][1], flags=re.MULTILINE).strip()[:900]
        answer = _translate_local_excerpt(excerpt, response_language)
    return {"answer": answer, "sources": [name], "mode": "local RAG", "grounded": True, "score": round(score, 3)}

def _assistant_fallback(language: str) -> str:
    if language == "ta":
        return "இந்த உள்ளூர் அறிவுத் தளத்தில் உங்கள் கேள்விக்கு போதுமான தகவல் இல்லை. அதிகாரப்பூர்வ இணையதளம் அல்லது உள்ளூர் அலுவலகத்தில் தற்போதைய விவரங்களைச் சரிபார்க்கவும்."
    return "The local knowledge base does not contain enough relevant information for this question. Please check the appropriate official source or local office for current details."

def _curated_local_answer(name: str, language: str) -> str | None:
    answers = {
        "irrigation": (
            "Irrigation guidance:\n\nInspect root-zone moisture, crop stage, soil texture, irrigation flow, and expected rain before watering. Prefer careful early-morning irrigation when appropriate, and avoid standing water.",
            "நீர்ப்பாசன வழிகாட்டல்:\n\nநீர் பாய்ச்சுவதற்கு முன் வேர் பகுதி ஈரப்பதம், பயிர் நிலை, மண் தன்மை, நீர்ப்பாசன ஓட்டம் மற்றும் எதிர்பார்க்கப்படும் மழையைச் சரிபார்க்கவும். பொருத்தமான நேரத்தில் அதிகாலை நீர்ப்பாசனம் செய்யவும்; நீர் தேங்குவதைத் தவிர்க்கவும்.",
        ),
        "soil": (
            "Soil and fertilizer guidance:\n\nUse a soil test to check pH and nutrient levels. Do not apply extra fertilizer using sensor values alone. Consider crop age, moisture, local guidance, and legal product instructions.",
            "மண் மற்றும் உர வழிகாட்டல்:\n\npH மற்றும் ஊட்டச்சத்து அளவுகளை அறிய மண் பரிசோதனை செய்யவும். சென்சார் மதிப்புகளை மட்டும் வைத்து கூடுதல் உரம் இட வேண்டாம். பயிரின் வயது, ஈரப்பதம், உள்ளூர் வழிகாட்டல் மற்றும் சட்டப்பூர்வ தயாரிப்பு வழிமுறைகளைப் பரிசீலிக்கவும்.",
        ),
        "disease_screening": (
            "Leaf screening guidance:\n\nUpload a clear image and treat the result as preliminary screening, not a diagnosis. Inspect both sides of leaves and consult a qualified local agricultural expert before treatment.",
            "இலைப் பரிசோதனை வழிகாட்டல்:\n\nதெளிவான படத்தைப் பதிவேற்றவும். முடிவை ஆரம்பகட்ட பரிசோதனையாக மட்டுமே கருதவும்; அது உறுதியான நோயறிதல் அல்ல. இலைகளின் இருபுறங்களையும் பார்த்து, சிகிச்சைக்கு முன் தகுதியான உள்ளூர் வேளாண் நிபுணரை அணுகவும்.",
        ),
        "government_forms": (
            "Government application guidance:\n\nUse the relevant official department or service portal. Check the current form version, eligibility, document list, fee, submission method, and acknowledgement directly with that authority. This local assistant does not verify live deadlines or scheme rules.",
            "அரசு விண்ணப்ப வழிகாட்டல்:\n\nதொடர்புடைய அதிகாரப்பூர்வ துறை அல்லது சேவை இணையதளத்தைப் பயன்படுத்தவும். தற்போதைய படிவம், தகுதி, ஆவணப் பட்டியல், கட்டணம், சமர்ப்பிக்கும் முறை மற்றும் பெறுபத்திரத்தை அந்த அதிகாரியிடமே சரிபார்க்கவும். இந்த உள்ளூர் உதவியாளரால் தற்போதைய காலக்கெடு அல்லது திட்ட விதிகளைச் சரிபார்க்க முடியாது.",
        ),
        "education": (
            "Education guidance:\n\nCompare the institution's official admission or scholarship notice, eligibility, required documents, deadline, and application process. Confirm current details with the institution because they change.",
            "கல்வி வழிகாட்டல்:\n\nகல்வி நிறுவனத்தின் அதிகாரப்பூர்வ சேர்க்கை அல்லது உதவித்தொகை அறிவிப்பில் தகுதி, தேவையான ஆவணங்கள், காலக்கெடு மற்றும் விண்ணப்ப முறையைச் சரிபார்க்கவும். இவை மாறக்கூடியதால் தற்போதைய விவரங்களை நிறுவனத்திடம் உறுதிப்படுத்தவும்.",
        ),
        "technology": (
            "Technology guidance:\n\nBreak the task into the input, expected output, tools, and error message. Keep backups, use official documentation, and avoid running commands you do not understand.",
            "தொழில்நுட்ப வழிகாட்டல்:\n\nசிக்கலை உள்ளீடு, எதிர்பார்க்கும் முடிவு, பயன்படுத்தும் கருவி மற்றும் பிழைச் செய்தி எனப் பிரிக்கவும். காப்புப்பிரதி வைத்துக் கொண்டு அதிகாரப்பூர்வ ஆவணங்களைப் பயன்படுத்தவும்; புரியாத கட்டளைகளை இயக்க வேண்டாம்.",
        ),
    }
    pair = answers.get(name)
    return pair[1] if pair and language == "ta" else pair[0] if pair else None

def _translate_local_excerpt(excerpt: str, language: str) -> str:
    if language == "ta":
        return "இந்தத் தலைப்புக்கான உள்ளூர் வழிகாட்டல்:\n\nமேலும் விவரங்களுக்கு தொடர்புடைய அதிகாரப்பூர்வ அல்லது உள்ளூர் நிபுணர் ஆதாரத்தைச் சரிபார்க்கவும்."
    return f"Relevant local guidance:\n\n{excerpt}\n\nConfirm important decisions with the appropriate local authority or qualified expert."

def _weather_context(data: dict) -> str:
    current = data.get("current", {})
    return (
        f"Weather location: {data.get('location', 'unknown')}\n"
        f"Temperature: {current.get('temperature_2m', 'unavailable')} °C\n"
        f"Relative humidity: {current.get('relative_humidity_2m', 'unavailable')}%\n"
        f"Precipitation: {current.get('precipitation', 'unavailable')} mm\n"
        f"Weather source: {data.get('source', 'unavailable')}"
    )

async def ai_assistant(
    question: str,
    response_language: str = "en",
    voice_language: str | None = None,
    user_id: int | None = None,
    location: str | None = None,
    latitude: float | None = None,
    longitude: float | None = None,
) -> dict:
    if user_id is None:
        raise AssistantServiceError(500, "The AI assistant session is unavailable.")
    prior = " ".join(_assistant_history[user_id])
    effective_question = f"{prior} {question}" if len(question.split()) <= 4 and prior else question
    result = local_rag(effective_question, response_language=response_language)
    _assistant_history[user_id].append(question)
    if result["sources"] and voice_language and voice_language != response_language:
        voice_result = local_rag(effective_question, response_language=voice_language)
        result["voice_answer"] = voice_result["answer"]
        result["voice_language"] = voice_language
    weather_data = await weather(location or "Coimbatore, India", latitude=latitude, longitude=longitude) if any(term in question.lower() for term in ("weather", "rain", "மழை", "வானிலை")) else None
    if weather_data:
        result["weather_context"] = _weather_context(weather_data)
        result["current_data_note"] = "Weather data is from the local weather adapter and may be simulated; verify severe-weather information with an official meteorological source."
    result["mode"] = result.get("mode", "local RAG")
    return result
